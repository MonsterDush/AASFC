from __future__ import annotations

from datetime import date
import json
import re

from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from app.auth.deps import get_current_user
from app.auth.passwords import has_password
from app.auth.phone_auth import get_user_auth_methods, get_user_phone
from app.core.db import get_db
from app.core.roles_registry import VENUE_ROLE_TO_DEFAULT_ROLE
from app.core.permissions_registry import PERMISSIONS as PERMISSIONS_REGISTRY
from app.models import (
    User,
    Venue,
    VenueMember,
    Permission,
    RolePermissionDefault,
    VenuePosition,
    Shift,
    ShiftAssignment,
    ShiftInterval,
    DailyReport,
    Adjustment,
    PayrollLine,
    PayrollRun,
    PayProfile,
)


router = APIRouter(tags=["me"])

def _parse_position_permission_codes(raw: str | None) -> list[str]:
    """Parse VenuePosition.permission_codes stored as JSON list (preferred) or tolerate legacy formats."""
    if not raw:
        return []
    s = str(raw).strip()
    if not s:
        return []
    # 1) JSON list
    try:
        data = json.loads(s)
        if isinstance(data, list):
            out: list[str] = []
            for x in data:
                v = str(x or "").strip().upper()
                if v and v not in out:
                    out.append(v)
            return out
    except Exception:
        pass

    # 2) fallback: comma/space separated list or python-like list string
    cleaned = s.replace("[", "").replace("]", "").replace('"', "").replace("'", "")
    out: list[str] = []
    for part in re.split(r"[\s,;]+", cleaned):
        v = str(part or "").strip().upper()
        if v and v not in out:
            out.append(v)
    return out


from pydantic import BaseModel, Field

class ProfileUpdateIn(BaseModel):
    full_name: str | None = Field(default=None, max_length=128)
    short_name: str | None = Field(default=None, max_length=64)





class NotificationSettingsIn(BaseModel):
    notify_enabled: bool | None = None
    notify_adjustments: bool | None = None
    notify_shifts: bool | None = None

@router.get("/me")
def me(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return {
        "id": user.id,
        "tg_user_id": user.tg_user_id,
        "tg_username": user.tg_username,
        "full_name": user.full_name,
        "short_name": user.short_name,
        "system_role": user.system_role,
        "notify_enabled": user.notify_enabled,
        "notify_adjustments": user.notify_adjustments,
        "notify_shifts": user.notify_shifts,
        "phone": get_user_phone(db, user_id=user.id),
        "auth_methods": get_user_auth_methods(db, user_id=user.id),
        "has_password": has_password(user),
        "password_set_at": user.password_set_at.isoformat() if user.password_set_at else None,
    }


@router.get("/me/permissions/catalog")
def my_permissions_catalog(user: User = Depends(get_current_user)):
    """Return full permission registry for dynamic UI builders.

    The list is sourced from code registry, so new permissions appear in UI
    immediately after frontend/backend deploy even before sync_permissions.
    """
    return {
        "items": [
            {
                "code": p.code,
                "group": p.group,
                "title": p.title,
                "description": p.description,
            }
            for p in PERMISSIONS_REGISTRY
        ]
    }



@router.get("/me/profile")
def get_profile(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return {
        "id": user.id,
        "tg_user_id": user.tg_user_id,
        "tg_username": user.tg_username,
        "full_name": user.full_name,
        "short_name": user.short_name,
        "phone": get_user_phone(db, user_id=user.id),
        "auth_methods": get_user_auth_methods(db, user_id=user.id),
        "has_password": has_password(user),
        "password_set_at": user.password_set_at.isoformat() if user.password_set_at else None,
    }


@router.patch("/me/profile")
def update_profile(
    payload: ProfileUpdateIn,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    # пустые строки считаем как None
    if payload.full_name is not None:
        v = payload.full_name.strip()
        user.full_name = v or None
    if payload.short_name is not None:
        v = payload.short_name.strip()
        user.short_name = v or None
    db.commit()
    return {"ok": True}


@router.get("/me/notification-settings")
def get_notification_settings(user: User = Depends(get_current_user)):
    return {
        "notify_enabled": user.notify_enabled,
        "notify_adjustments": user.notify_adjustments,
        "notify_shifts": user.notify_shifts,
    }


@router.patch("/me/notification-settings")
def update_notification_settings(
    payload: NotificationSettingsIn,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if payload.notify_enabled is not None:
        user.notify_enabled = bool(payload.notify_enabled)
    if payload.notify_adjustments is not None:
        user.notify_adjustments = bool(payload.notify_adjustments)
    if payload.notify_shifts is not None:
        user.notify_shifts = bool(payload.notify_shifts)
    db.commit()
    return {"ok": True}


@router.get("/me/venues")
def my_venues(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    rows = db.execute(
        select(Venue.id, Venue.name, VenueMember.venue_role)
        .join(VenueMember, VenueMember.venue_id == Venue.id)
        .where(
            VenueMember.user_id == user.id,
            VenueMember.is_active.is_(True),
        )
        .order_by(Venue.id.desc())
    ).all()

    return [{"id": r.id, "name": r.name, "my_role": r.venue_role} for r in rows]


@router.get("/me/venues/{venue_id}/members")
def my_venue_members(
    venue_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    # доступ: любой активный member этого venue
    vm = db.execute(
        select(VenueMember).where(
            VenueMember.venue_id == venue_id,
            VenueMember.user_id == user.id,
            VenueMember.is_active.is_(True),
        )
    ).scalar_one_or_none()

    if vm is None and user.system_role not in ("SUPER_ADMIN", "MODERATOR"):
        # можно 403 — так правильнее
        return {"venue_id": venue_id, "members": []}

    rows = db.execute(
        select(User.id, User.tg_user_id, User.tg_username, User.full_name, User.short_name, VenueMember.venue_role)
        .join(VenueMember, VenueMember.user_id == User.id)
        .where(
            VenueMember.venue_id == venue_id,
            VenueMember.is_active.is_(True),
        )
        .order_by(VenueMember.venue_role.asc(), User.id.asc())
    ).all()

    return {
        "venue_id": venue_id,
        "members": [
            {
                "user_id": r.id,
                "tg_user_id": r.tg_user_id,
                "tg_username": r.tg_username,
                "full_name": r.full_name,
                "short_name": r.short_name,
                "venue_role": r.venue_role,
            }
            for r in rows
        ],
    }


@router.get("/me/venues/{venue_id}/permissions")
def my_venue_permissions(
    venue_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Return permissions + venue role for current user.

    Source of truth:
    - System roles / venue role defaults (RolePermissionDefault)
    - VenuePosition.permission_codes (fine-grained codes)
    """

    # ---- system roles ----
    if user.system_role == "SUPER_ADMIN":
        codes = db.scalars(select(Permission.code).where(Permission.is_active.is_(True))).all()
        return {
            "venue_id": venue_id,
            "role": "SUPER_ADMIN",
            "permissions": list(codes),
            "position": None,
        }

    if user.system_role == "MODERATOR":
        codes = db.scalars(
            select(RolePermissionDefault.permission_code)
            .join(Permission, Permission.code == RolePermissionDefault.permission_code)
            .where(
                RolePermissionDefault.role == "MODERATOR",
                RolePermissionDefault.is_granted_by_default.is_(True),
                Permission.is_active.is_(True),
            )
        ).all()
        return {
            "venue_id": venue_id,
            "role": "MODERATOR",
            "permissions": list(codes),
            "position": None,
        }

    # ---- venue membership ----
    vm = db.execute(
        select(VenueMember).where(
            VenueMember.venue_id == venue_id,
            VenueMember.user_id == user.id,
            VenueMember.is_active.is_(True),
        )
    ).scalar_one_or_none()

    if vm is None:
        return {
            "venue_id": venue_id,
            "role": None,
            "permissions": [],
            "position": None,
        }

    if str(vm.venue_role or "").upper() == "OWNER":
        # OWNER has full access inside their venue
        all_codes = db.scalars(select(Permission.code).where(Permission.is_active.is_(True))).all()
        codes = list(all_codes)
        defaults_role = None
    else:
        defaults_role = VENUE_ROLE_TO_DEFAULT_ROLE.get(vm.venue_role)
        if not defaults_role:
            codes = []
        else:
            codes = db.scalars(
                select(RolePermissionDefault.permission_code)
                .join(Permission, Permission.code == RolePermissionDefault.permission_code)
                .where(
                    RolePermissionDefault.role == defaults_role,
                    RolePermissionDefault.is_granted_by_default.is_(True),
                    Permission.is_active.is_(True),
                )
            ).all()

    # ---- position permission codes (fine-grained) ----
    pos = db.execute(
        select(VenuePosition).where(
            VenuePosition.venue_id == venue_id,
            VenuePosition.member_user_id == user.id,
            VenuePosition.is_active.is_(True),
        )
    ).scalar_one_or_none()

    position_codes: list[str] = []
    position_obj = None
    if pos is not None:
        position_codes = _parse_position_permission_codes(getattr(pos, "permission_codes", None))
        position_obj = {
            "id": pos.id,
            "title": pos.title,
            "rate": pos.rate,
            "percent": pos.percent,
            "is_active": bool(pos.is_active),
            "permission_codes": position_codes,
        }

    # filter position codes by active permissions in DB (or registry, even if sync wasn't run yet)
    merged = list(codes) if codes else []
    if position_codes:
        active = set(
            db.execute(select(Permission.code).where(Permission.code.in_(position_codes), Permission.is_active.is_(True))).scalars().all()
        )
        registry = {p.code.strip().upper() for p in PERMISSIONS_REGISTRY}
        for c in [str(x or "").strip().upper() for x in position_codes]:
            if not c:
                continue
            if (c in active or c in registry) and c not in merged:
                merged.append(c)

    return {
        "venue_id": venue_id,
        "role": vm.venue_role,
        "permissions": merged,
        "position": position_obj,
    }





def _parse_month_range(month: str) -> tuple[date, date]:
    try:
        y_s, m_s = month.split("-")
        y = int(y_s)
        m = int(m_s)
        start = date(y, m, 1)
        end = date(y + 1, 1, 1) if m == 12 else date(y, m + 1, 1)
        return start, end
    except Exception:
        raise HTTPException(status_code=400, detail="Bad month format, expected YYYY-MM")


def _load_payroll_summary_by_venue(db: Session, *, user_id: int, month_start: date) -> dict[int, dict]:
    rows = db.execute(
        select(
            PayrollLine.venue_id,
            Venue.name.label("venue_name"),
            func.coalesce(func.sum(PayrollLine.amount_minor), 0).label("earned_minor"),
            func.max(PayrollLine.id).label("payroll_line_id"),
        )
        .join(PayrollRun, PayrollRun.id == PayrollLine.payroll_run_id)
        .join(Venue, Venue.id == PayrollLine.venue_id)
        .where(
            PayrollLine.member_user_id == int(user_id),
            PayrollRun.period_month == month_start,
        )
        .group_by(PayrollLine.venue_id, Venue.name)
    ).all()
    out: dict[int, dict] = {}
    for row in rows:
        vid = int(row.venue_id)
        earned_minor = int(row.earned_minor or 0)
        out[vid] = {
            "venue_id": vid,
            "venue_name": row.venue_name or "",
            "earned_minor": earned_minor,
            "earned": int(round(earned_minor / 100.0)),
            "source": "payroll",
            "payroll_line_id": int(row.payroll_line_id) if row.payroll_line_id is not None else None,
        }
    return out


@router.get("/me/shifts")
def my_shifts_across_venues(
    month: str = Query(..., description="YYYY-MM"),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Return current user's shifts across all active venues (for 'Общий' calendar)."""

    try:
        y_s, m_s = month.split("-")
        y = int(y_s)
        m = int(m_s)
        start = date(y, m, 1)
        end = date(y + 1, 1, 1) if m == 12 else date(y, m + 1, 1)
    except Exception:
        raise HTTPException(status_code=400, detail="Bad month format, expected YYYY-MM")

    # only shifts where the user is assigned
    rows = db.execute(
        select(
            Shift.id.label("shift_id"),
            Shift.date.label("shift_date"),
            Shift.venue_id.label("venue_id"),
            Venue.name.label("venue_name"),
            Shift.interval_id.label("interval_id"),
            ShiftInterval.title.label("interval_title"),
            ShiftInterval.start_time.label("start_time"),
            ShiftInterval.end_time.label("end_time"),
            VenuePosition.rate.label("rate"),
            VenuePosition.percent.label("percent"),
        )
        .select_from(ShiftAssignment)  # <-- ВАЖНО: фиксируем левую таблицу
        .join(Shift, Shift.id == ShiftAssignment.shift_id)
        .join(Venue, Venue.id == Shift.venue_id)
        .join(ShiftInterval, ShiftInterval.id == Shift.interval_id)
        .join(VenuePosition, VenuePosition.id == ShiftAssignment.venue_position_id)
        .where(
            ShiftAssignment.member_user_id == user.id,
            Shift.is_active.is_(True),
            Shift.date >= start,
            Shift.date < end,
        )
        .order_by(Shift.date.asc(), Shift.id.asc())
    ).all()


    if not rows:
        return []

    # preload daily reports per (venue_id, date) for salary calc
    keys = {(r.venue_id, r.shift_date) for r in rows}
    reports = db.execute(
        select(DailyReport).where(
            DailyReport.venue_id.in_({k[0] for k in keys}),
            DailyReport.date.in_({k[1] for k in keys}),
        )
    ).scalars().all()
    report_by_key = {(r.venue_id, r.date): r for r in reports}

    out = []
    for r in rows:
        rep = report_by_key.get((r.venue_id, r.shift_date))
        my_salary = None
        revenue_total = None
        if rep is not None:
            revenue_total = rep.revenue_total
            try:
                my_salary = int(r.rate) + (int(r.percent) / 100.0) * rep.revenue_total
            except Exception:
                my_salary = None

        out.append(
            {
                "shift_id": r.shift_id,
                "date": r.shift_date.isoformat(),
                "venue": {"id": r.venue_id, "name": r.venue_name},
                "interval": {
                    "id": r.interval_id,
                    "title": r.interval_title,
                    "start_time": r.start_time.strftime("%H:%M"),
                    "end_time": r.end_time.strftime("%H:%M"),
                },
                "my_salary": my_salary,
                "revenue_total": revenue_total,
            }
        )

    return out


@router.get("/me/payroll-line")
def my_payroll_line(
    month: str = Query(..., description="YYYY-MM"),
    venue_id: int | None = Query(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    month_start, _month_end = _parse_month_range(month)

    rows = db.execute(
        select(PayrollLine, PayrollRun, Venue, PayProfile)
        .join(PayrollRun, PayrollRun.id == PayrollLine.payroll_run_id)
        .join(Venue, Venue.id == PayrollLine.venue_id)
        .outerjoin(PayProfile, PayProfile.id == PayrollLine.pay_profile_id)
        .where(
            PayrollLine.member_user_id == int(user.id),
            PayrollRun.period_month == month_start,
            *([PayrollLine.venue_id == int(venue_id)] if venue_id is not None else []),
        )
        .order_by(Venue.name.asc(), PayrollLine.id.asc())
    ).all()

    items = []
    for line, run, venue, profile in rows:
        try:
            breakdown = json.loads(line.breakdown_json) if line.breakdown_json else None
        except Exception:
            breakdown = None
        items.append(
            {
                "id": int(line.id),
                "venue": {"id": int(venue.id), "name": venue.name},
                "month": month,
                "amount_minor": int(line.amount_minor or 0),
                "amount": int(round(int(line.amount_minor or 0) / 100.0)),
                "pay_profile_id": int(line.pay_profile_id) if line.pay_profile_id is not None else None,
                "pay_profile_title": profile.title if profile is not None else None,
                "run": {
                    "id": int(run.id),
                    "calculated_at": run.calculated_at.isoformat() if run.calculated_at else None,
                },
                "breakdown": breakdown,
                "source": "payroll",
            }
        )

    if venue_id is not None:
        return items[0] if items else None
    return {"month": month, "items": items}


@router.get("/me/salary-summary")
def my_salary_summary(
    month: str = Query(..., description="YYYY-MM"),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Monthly salary summary across all venues for current user.

    The employee salary screen is payroll-only. If a venue/month has no
    payroll calculation yet, it is intentionally omitted from the summary so
    the frontend can show a clear "not calculated" state instead of a legacy
    shift-based approximation.
    """

    start, end = _parse_month_range(month)

    payroll_by_venue = _load_payroll_summary_by_venue(db, user_id=int(user.id), month_start=start)
    payroll_venue_ids = set(payroll_by_venue.keys())
    if not payroll_venue_ids:
        return {
            "month": month,
            "items": [],
            "totals": {
                "earned": 0,
                "tips": 0,
                "bonuses": 0,
                "penalties": 0,
                "net": 0,
            },
        }

    shift_rows = db.execute(
        select(
            Shift.id.label("shift_id"),
            Shift.venue_id.label("venue_id"),
            Shift.date.label("shift_date"),
        )
        .select_from(ShiftAssignment)
        .join(Shift, Shift.id == ShiftAssignment.shift_id)
        .where(
            ShiftAssignment.member_user_id == user.id,
            Shift.is_active.is_(True),
            Shift.venue_id.in_(payroll_venue_ids),
            Shift.date >= start,
            Shift.date < end,
        )
    ).all()

    tips_by_venue: dict[int, int] = {}
    if shift_rows:
        keys = {(int(r.venue_id), r.shift_date) for r in shift_rows}
        shift_ids = [int(r.shift_id) for r in shift_rows]
        report_by_key = {}
        if keys:
            reports = db.execute(
                select(DailyReport).where(
                    DailyReport.venue_id.in_({k[0] for k in keys}),
                    DailyReport.date.in_({k[1] for k in keys}),
                    DailyReport.status == "CLOSED",
                )
            ).scalars().all()
            report_by_key = {(int(r.venue_id), r.date): r for r in reports}

        assignee_cnt_by_shift: dict[int, int] = {}
        if shift_ids:
            cnt_rows = db.execute(
                select(ShiftAssignment.shift_id, func.count(ShiftAssignment.member_user_id))
                .where(ShiftAssignment.shift_id.in_(shift_ids))
                .group_by(ShiftAssignment.shift_id)
            ).all()
            assignee_cnt_by_shift = {int(sid): int(cnt or 0) for sid, cnt in cnt_rows}

        for r in shift_rows:
            rep = report_by_key.get((int(r.venue_id), r.shift_date))
            if rep is None:
                continue
            try:
                tips_total = int(getattr(rep, "tips_total", 0) or 0)
                if tips_total > 0:
                    cnt = max(1, int(assignee_cnt_by_shift.get(int(r.shift_id), 1)))
                    my_tips = int(round(float(tips_total) / float(cnt)))
                    tips_by_venue[int(r.venue_id)] = tips_by_venue.get(int(r.venue_id), 0) + my_tips
            except Exception:
                pass

    adj_rows = db.execute(
        select(Adjustment.venue_id, Adjustment.type, Adjustment.amount)
        .where(
            Adjustment.member_user_id == user.id,
            Adjustment.is_active.is_(True),
            Adjustment.venue_id.in_(payroll_venue_ids),
            Adjustment.date >= start,
            Adjustment.date < end,
        )
    ).all()

    bonuses_by_venue: dict[int, int] = {}
    penalties_by_venue: dict[int, int] = {}
    for v_id, typ, amount in adj_rows:
        vid = int(v_id)
        t = str(typ or "").lower()
        a = int(amount or 0)
        if t == "bonus":
            bonuses_by_venue[vid] = bonuses_by_venue.get(vid, 0) + a
        else:
            penalties_by_venue[vid] = penalties_by_venue.get(vid, 0) + a

    items = []
    total_net = 0
    total_earned = 0
    total_tips = 0
    total_bonus = 0
    total_pen = 0

    for vid in sorted(payroll_venue_ids):
        payroll_item = payroll_by_venue.get(vid) or {}
        earned = int(payroll_item.get("earned") or 0)
        tips = int(tips_by_venue.get(vid, 0))
        bonus = int(bonuses_by_venue.get(vid, 0))
        pen = int(penalties_by_venue.get(vid, 0))
        net = earned + tips + bonus - pen
        total_net += net
        total_earned += earned
        total_tips += tips
        total_bonus += bonus
        total_pen += pen
        item = {
            "venue": {"id": vid, "name": payroll_item.get("venue_name") or ""},
            "earned": earned,
            "tips": tips,
            "bonuses": bonus,
            "penalties": pen,
            "net": net,
            "source": "payroll",
            "calculated": True,
            "earned_minor": int(payroll_item.get("earned_minor") or 0),
        }
        if payroll_item.get("payroll_line_id") is not None:
            item["payroll_line_id"] = payroll_item["payroll_line_id"]
        items.append(item)

    return {
        "month": month,
        "items": items,
        "totals": {
            "earned": total_earned,
            "tips": total_tips,
            "bonuses": total_bonus,
            "penalties": total_pen,
            "net": total_net,
        },
    }
