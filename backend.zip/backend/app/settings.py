# backend/app/settings.py
from app.core.config import settings  # noqa: F401
