from __future__ import annotations

import calendar
import json
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from typing import Iterable

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import (
    Adjustment,
    DailyReport,
    DailyReportAudit,
    DailyReportTipAllocation,
    DailyReportValue,
    Department,
    Expense,
    ExpenseCategory,
    KpiMetric,
    PayComponent,
    PayProfile,
    PayProfileAssignment,
    PaymentMethod,
    PayrollRun,
    Shift,
    ShiftAssignment,
    ShiftComment,
    ShiftInterval,
    Supplier,
    User,
    Venue,
    VenueBillingEvent,
    VenueBillingState,
    VenueBillingTransaction,
    VenueMember,
    VenuePosition,
)
from app.services.billing.manager import get_or_create_billing_state
from app.services.demo.fixture import clear_demo_venue_data, export_demo_fixture
from app.services.demo.session import DEMO_PERSONA_OWNER, DEMO_PERSONA_STAFF
from app.services.finance.expenses import rebuild_expense_allocations_for_expense
from app.services.payroll import calculate_payroll_for_month


DEFAULT_DEMO_REFERENCE_YEAR = 2026
DEFAULT_DEMO_REFERENCE_MONTH = 3
DEFAULT_DEMO_VENUE_NAME = "Axelio DEMO · Hookah Lounge"

OWNER_PERMISSIONS: list[str] = []
HOOKAH_REPORTER_PERMISSIONS = [
    "SHIFT_REPORT_VIEW",
    "SHIFT_REPORT_EDIT",
    "SHIFT_REPORT_CLOSE",
    "DEPARTMENTS_VIEW",
    "PAYMENT_METHODS_VIEW",
    "KPI_METRICS_VIEW",
]


@dataclass
class DemoBootstrapResult:
    venue_id: int
    venue_name: str
    reference_year: int
    reference_month: int
    fixture_path: str | None
    counts: dict[str, int]
    warnings: list[str]


def _slug(value: str) -> str:
    raw = "".join(ch.lower() if ch.isalnum() else "-" for ch in str(value or "").strip())
    while "--" in raw:
        raw = raw.replace("--", "-")
    return raw.strip("-") or "demo"


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _month_start(year: int, month: int) -> date:
    return date(int(year), int(month), 1)


def _month_end(year: int, month: int) -> date:
    return date(int(year), int(month), calendar.monthrange(int(year), int(month))[1])


def _month_iter(year: int, month: int) -> Iterable[date]:
    cur = _month_start(year, month)
    end = _month_end(year, month)
    while cur <= end:
        yield cur
        cur += timedelta(days=1)


def _require_safe_target_venue(db: Session, venue: Venue) -> None:
    if bool(getattr(venue, "is_demo", False)):
        return
    non_demo_members = int(db.execute(
        select(func.count(VenueMember.id))
        .join(User, User.id == VenueMember.user_id)
        .where(VenueMember.venue_id == int(venue.id), User.is_demo_user.is_(False))
    ).scalar() or 0)
    has_live_content = any(
        int(db.execute(select(func.count(model.id)).where(model.venue_id == int(venue.id))).scalar() or 0) > 0
        for model in [Shift, DailyReport, Expense, PayrollRun]
    )
    if non_demo_members or has_live_content:
        raise ValueError(
            "Bootstrap DEMO можно запускать только на DEMO-заведении или на пустом venue без боевых данных"
        )


def _ensure_venue(db: Session, *, venue_id: int | None, venue_name: str, reference_year: int, reference_month: int, make_public: bool) -> Venue:
    venue: Venue | None = None
    if venue_id is not None:
        venue = db.execute(select(Venue).where(Venue.id == int(venue_id))).scalar_one_or_none()
        if venue is None:
            raise ValueError(f"Venue #{int(venue_id)} not found")
        _require_safe_target_venue(db, venue)
    else:
        venue = Venue(name=venue_name)
        db.add(venue)
        db.flush()

    venue.name = venue_name
    venue.is_demo = bool(make_public)
    venue.demo_reference_year = int(reference_year)
    venue.demo_reference_month = int(reference_month)
    venue.is_archived = False
    venue.archived_at = None
    venue.tips_enabled = True
    venue.tips_split_mode = "EQUAL"
    venue.tips_weights = None
    db.flush()
    return venue


def _build_demo_users() -> list[dict]:
    return [
        {
            "key": "owner",
            "persona": DEMO_PERSONA_OWNER,
            "venue_role": "OWNER",
            "full_name": "Владимир Демов",
            "short_name": "Владелец",
            "tg_username": "axelio_demo_owner",
            "position_title": None,
            "profile_key": None,
            "permission_codes": OWNER_PERMISSIONS,
        },
        {
            "key": "staff_persona",
            "persona": DEMO_PERSONA_STAFF,
            "venue_role": "STAFF",
            "full_name": "Илья Орлов",
            "short_name": "Илья",
            "tg_username": "axelio_demo_staff",
            "position_title": "Кальянный мастер",
            "profile_key": "hookah",
            "permission_codes": [],
        },
        {
            "key": "anna_admin",
            "persona": None,
            "venue_role": "STAFF",
            "full_name": "Анна Соколова",
            "short_name": "Анна",
            "tg_username": "axelio_demo_anna",
            "position_title": "Администратор",
            "profile_key": "admin",
            "permission_codes": [],
        },
        {
            "key": "kirill_hookah",
            "persona": None,
            "venue_role": "STAFF",
            "full_name": "Кирилл Громов",
            "short_name": "Кирилл",
            "tg_username": "axelio_demo_kirill",
            "position_title": "Кальянный мастер",
            "profile_key": "hookah",
            "permission_codes": HOOKAH_REPORTER_PERMISSIONS,
        },
        {
            "key": "maksim_hookah",
            "persona": None,
            "venue_role": "STAFF",
            "full_name": "Максим Новиков",
            "short_name": "Максим",
            "tg_username": "axelio_demo_maksim",
            "position_title": "Кальянный мастер",
            "profile_key": "hookah",
            "permission_codes": [],
        },
        {
            "key": "maria_bar",
            "persona": None,
            "venue_role": "STAFF",
            "full_name": "Мария Белова",
            "short_name": "Мария",
            "tg_username": "axelio_demo_maria",
            "position_title": "Бар",
            "profile_key": "bar",
            "permission_codes": [],
        },
        {
            "key": "aleksey_waiter",
            "persona": None,
            "venue_role": "STAFF",
            "full_name": "Алексей Фомин",
            "short_name": "Алексей",
            "tg_username": "axelio_demo_alex",
            "position_title": "Официант",
            "profile_key": "floor",
            "permission_codes": [],
        },
        {
            "key": "polina_waiter",
            "persona": None,
            "venue_role": "STAFF",
            "full_name": "Полина Кузнецова",
            "short_name": "Полина",
            "tg_username": "axelio_demo_polina",
            "position_title": "Официант",
            "profile_key": "floor",
            "permission_codes": [],
        },
        {
            "key": "daniil_host",
            "persona": None,
            "venue_role": "STAFF",
            "full_name": "Даниил Морозов",
            "short_name": "Даниил",
            "tg_username": "axelio_demo_daniil",
            "position_title": "Хостес",
            "profile_key": "host",
            "permission_codes": [],
        },
        {
            "key": "sofia_manager",
            "persona": None,
            "venue_role": "STAFF",
            "full_name": "София Волкова",
            "short_name": "София",
            "tg_username": "axelio_demo_sofia",
            "position_title": "Старший смены",
            "profile_key": "admin",
            "permission_codes": HOOKAH_REPORTER_PERMISSIONS,
        },
    ]


def _create_user(db: Session, spec: dict) -> User:
    user = User(
        tg_username=spec.get("tg_username"),
        full_name=spec.get("full_name"),
        short_name=spec.get("short_name"),
        system_role="NONE",
        notify_enabled=False,
        notify_adjustments=False,
        notify_shifts=False,
        notify_shift_comments=False,
        notify_day_economics=False,
        notify_salary=False,
        notify_soft_alerts=False,
        shift_reminder_lead_time_hours=18,
        notification_detail_level="standard",
        is_demo_user=True,
        demo_persona=spec.get("persona"),
    )
    db.add(user)
    db.flush()
    return user


def _create_member_and_position(db: Session, *, venue: Venue, user: User, spec: dict) -> VenuePosition | None:
    db.add(VenueMember(
        venue_id=int(venue.id),
        user_id=int(user.id),
        venue_role=str(spec.get("venue_role") or "STAFF").upper(),
        is_active=True,
    ))
    position_title = spec.get("position_title")
    if not position_title:
        return None
    permission_codes = spec.get("permission_codes") or []
    position = VenuePosition(
        venue_id=int(venue.id),
        member_user_id=int(user.id),
        title=str(position_title),
        rate=0,
        percent=0,
        permission_codes=json.dumps(permission_codes, ensure_ascii=False) if permission_codes else None,
        is_active=True,
    )
    db.add(position)
    db.flush()
    return position


def _create_dictionaries(db: Session, *, venue: Venue) -> dict:
    departments = [
        Department(venue_id=int(venue.id), code="hookah", title="Кальянный зал", sort_order=10, is_active=True),
        Department(venue_id=int(venue.id), code="bar", title="Бар", sort_order=20, is_active=True),
        Department(venue_id=int(venue.id), code="kitchen", title="Кухня", sort_order=30, is_active=True),
    ]
    payment_methods = [
        PaymentMethod(venue_id=int(venue.id), code="cash", title="Наличные", sort_order=10, is_active=True),
        PaymentMethod(venue_id=int(venue.id), code="cashless", title="Карта", sort_order=20, is_active=True),
        PaymentMethod(venue_id=int(venue.id), code="sbp", title="СБП", sort_order=30, is_active=True),
        PaymentMethod(venue_id=int(venue.id), code="other", title="Прочее", sort_order=40, is_active=True),
    ]
    kpis = [
        KpiMetric(venue_id=int(venue.id), code="upsale", title="Допродажи", unit="QTY", sort_order=10, is_active=True),
        KpiMetric(venue_id=int(venue.id), code="vip", title="VIP столы", unit="QTY", sort_order=20, is_active=True),
        KpiMetric(venue_id=int(venue.id), code="retail", title="Ритейл", unit="RUB", sort_order=30, is_active=True),
    ]
    categories = [
        ExpenseCategory(venue_id=int(venue.id), code="rent", title="Аренда", sort_order=10, is_active=True),
        ExpenseCategory(venue_id=int(venue.id), code="tobacco", title="Табак и смеси", sort_order=20, is_active=True),
        ExpenseCategory(venue_id=int(venue.id), code="barstock", title="Закуп бара", sort_order=30, is_active=True),
        ExpenseCategory(venue_id=int(venue.id), code="supplies", title="Хоз. расходы", sort_order=40, is_active=True),
        ExpenseCategory(venue_id=int(venue.id), code="marketing", title="Маркетинг", sort_order=50, is_active=True),
    ]
    suppliers = [
        Supplier(venue_id=int(venue.id), title="Darkside Distribution", contact="@darkside_demo", sort_order=10, is_active=True),
        Supplier(venue_id=int(venue.id), title="Metro Cash & Carry", contact="+7 800 700-10-77", sort_order=20, is_active=True),
        Supplier(venue_id=int(venue.id), title="Local Partner", contact="@axelio_partner", sort_order=30, is_active=True),
    ]
    for item in [*departments, *payment_methods, *kpis, *categories, *suppliers]:
        db.add(item)
    db.flush()
    return {
        "departments": {item.code: item for item in departments},
        "payment_methods": {item.code: item for item in payment_methods},
        "kpis": {item.code: item for item in kpis},
        "categories": {item.code: item for item in categories},
        "suppliers": {item.title: item for item in suppliers},
    }


def _create_intervals(db: Session, *, venue: Venue) -> dict[str, ShiftInterval]:
    opening = ShiftInterval(venue_id=int(venue.id), title="Открытие", start_time=time(12, 0), end_time=time(18, 0), is_active=True)
    evening = ShiftInterval(venue_id=int(venue.id), title="Вечер", start_time=time(18, 0), end_time=time(23, 45), is_active=True)
    db.add_all([opening, evening])
    db.flush()
    return {"opening": opening, "evening": evening}


def _rotation_pick(pool: list[str], idx: int, count: int) -> list[str]:
    if not pool or count <= 0:
        return []
    out = []
    for shift in range(count):
        out.append(pool[(idx + shift) % len(pool)])
    return out


def _create_schedule(db: Session, *, venue: Venue, reference_year: int, reference_month: int, users_by_key: dict[str, User], positions_by_key: dict[str, VenuePosition], owner_user: User) -> dict[str, int]:
    intervals = _create_intervals(db, venue=venue)
    hookah_keys = ["staff_persona", "kirill_hookah", "maksim_hookah"]
    floor_keys = ["aleksey_waiter", "polina_waiter"]
    admin_keys = ["anna_admin", "sofia_manager"]
    host_keys = ["daniil_host"]
    bar_keys = ["maria_bar"]
    created_shifts = 0
    created_assignments = 0
    created_comments = 0

    for idx, day in enumerate(_month_iter(reference_year, reference_month)):
        opening_shift = Shift(venue_id=int(venue.id), date=day, interval_id=int(intervals["opening"].id), created_by_user_id=int(owner_user.id), is_active=True)
        evening_shift = Shift(venue_id=int(venue.id), date=day, interval_id=int(intervals["evening"].id), created_by_user_id=int(owner_user.id), is_active=True)
        db.add_all([opening_shift, evening_shift])
        db.flush()
        created_shifts += 2

        opening_staff = []
        opening_staff += _rotation_pick(admin_keys, idx, 1)
        opening_staff += _rotation_pick(hookah_keys, idx, 1)
        opening_staff += _rotation_pick(host_keys, idx, 1)
        if day.weekday() in {4, 5, 6}:
            opening_staff += _rotation_pick(floor_keys, idx, 1)

        evening_staff = []
        evening_staff += _rotation_pick(admin_keys, idx + 1, 1)
        evening_staff += _rotation_pick(hookah_keys, idx + 1, 2)
        evening_staff += _rotation_pick(bar_keys, idx, 1)
        evening_staff += _rotation_pick(floor_keys, idx + 1, 1)
        if day.weekday() in {4, 5}:
            evening_staff += _rotation_pick(host_keys, idx, 1)

        for shift_obj, keys in ((opening_shift, opening_staff), (evening_shift, evening_staff)):
            seen: set[str] = set()
            for key in keys:
                if key in seen:
                    continue
                seen.add(key)
                pos = positions_by_key.get(key)
                if pos is None:
                    continue
                db.add(ShiftAssignment(
                    shift_id=int(shift_obj.id),
                    member_user_id=int(users_by_key[key].id),
                    venue_position_id=int(pos.id),
                ))
                created_assignments += 1

        if day.day in {3, 8, 15, 22, 28}:
            db.add(ShiftComment(
                shift_id=int(evening_shift.id),
                author_user_id=int(users_by_key["anna_admin"].id),
                text="Подготовить VIP-зал, проверить остатки табака и открыть предзаказы на вечер.",
            ))
            created_comments += 1

    db.flush()
    return {
        "shift_intervals": 2,
        "shifts": created_shifts,
        "shift_assignments": created_assignments,
        "shift_comments": created_comments,
    }


def _daily_base_minor(day: date) -> int:
    if day.weekday() in {4, 5}:  # fri/sat
        return 9200000
    if day.weekday() == 6:
        return 7600000
    if day.weekday() == 0:
        return 4800000
    return 6100000


def _create_reports(db: Session, *, venue: Venue, reference_year: int, reference_month: int, users_by_key: dict[str, User], dictionaries: dict) -> dict[str, int]:
    pm = dictionaries["payment_methods"]
    dept = dictionaries["departments"]
    kpis = dictionaries["kpis"]
    created_reports = 0
    created_values = 0
    created_audits = 0
    created_tips = 0
    owner_user = users_by_key["owner"]
    admin_user = users_by_key["anna_admin"]

    for idx, day in enumerate(_month_iter(reference_year, reference_month)):
        total_minor = _daily_base_minor(day) + ((idx % 5) * 250000)
        hookah_minor = int(total_minor * 0.58)
        bar_minor = int(total_minor * 0.27)
        kitchen_minor = total_minor - hookah_minor - bar_minor

        cash_minor = int(total_minor * 0.22)
        cashless_minor = int(total_minor * 0.53)
        sbp_minor = int(total_minor * 0.20)
        other_minor = total_minor - cash_minor - cashless_minor - sbp_minor

        discrepancy = 0
        comment = None
        if day.day in {12, 27}:
            discrepancy = 70000
            cash_minor += discrepancy
            comment = "В пробном режиме показан день с расхождением: часть оплаты прошла после закрытия смены."

        tips_total = 340000 + (idx % 4) * 55000
        report = DailyReport(
            venue_id=int(venue.id),
            date=day,
            cash=cash_minor,
            cashless=cashless_minor + sbp_minor,
            revenue_total=total_minor,
            tips_total=tips_total,
            status="CLOSED",
            comment=comment,
            closed_by_user_id=int(admin_user.id),
            closed_at=datetime.combine(day, time(23, 30), tzinfo=timezone.utc),
            created_by_user_id=int(admin_user.id),
            created_at=datetime.combine(day, time(23, 0), tzinfo=timezone.utc),
            updated_by_user_id=int(admin_user.id),
            updated_at=datetime.combine(day, time(23, 35), tzinfo=timezone.utc),
        )
        db.add(report)
        db.flush()
        created_reports += 1

        values = [
            ("PAYMENT", int(pm["cash"].id), cash_minor),
            ("PAYMENT", int(pm["cashless"].id), cashless_minor),
            ("PAYMENT", int(pm["sbp"].id), sbp_minor),
            ("PAYMENT", int(pm["other"].id), other_minor),
            ("DEPT", int(dept["hookah"].id), hookah_minor),
            ("DEPT", int(dept["bar"].id), bar_minor),
            ("DEPT", int(dept["kitchen"].id), kitchen_minor),
            ("KPI", int(kpis["upsale"].id), 12 + (idx % 7)),
            ("KPI", int(kpis["vip"].id), 2 + (1 if day.weekday() in {4, 5} else 0)),
            ("KPI", int(kpis["retail"].id), 70000 + (idx % 6) * 10000),
        ]
        for kind, ref_id, value in values:
            db.add(DailyReportValue(report_id=int(report.id), kind=kind, ref_id=int(ref_id), value_numeric=int(value)))
            created_values += 1

        tip_receivers = ["staff_persona", "kirill_hookah", "maria_bar"] if day.weekday() in {4, 5} else ["staff_persona", "aleksey_waiter"]
        share = tips_total // len(tip_receivers)
        remainder = tips_total % len(tip_receivers)
        for t_idx, key in enumerate(tip_receivers):
            db.add(DailyReportTipAllocation(
                report_id=int(report.id),
                user_id=int(users_by_key[key].id),
                amount=int(share + (remainder if t_idx == 0 else 0)),
                split_mode="EQUAL",
                meta_json={"demo": True},
            ))
            created_tips += 1

        if day.day in {5, 12}:
            db.add(DailyReportAudit(
                report_id=int(report.id),
                user_id=int(owner_user.id),
                changed_at=datetime.combine(day, time(23, 40), tzinfo=timezone.utc),
                diff_json={
                    "status": "CLOSED",
                    "comment": comment,
                    "note": "Демо-аудит: фиксируем пример правки закрытого отчёта",
                },
            ))
            created_audits += 1

    db.flush()
    return {
        "daily_reports": created_reports,
        "daily_report_values": created_values,
        "daily_report_tip_allocations": created_tips,
        "daily_report_audits": created_audits,
    }


def _create_expenses(db: Session, *, venue: Venue, dictionaries: dict, users_by_key: dict[str, User], reference_year: int, reference_month: int) -> dict[str, int]:
    categories = dictionaries["categories"]
    suppliers = dictionaries["suppliers"]
    payment_methods = dictionaries["payment_methods"]
    owner = users_by_key["owner"]
    items = [
        ("rent", "Metro Cash & Carry", 13500000, date(reference_year, reference_month, 5), 1, "Аренда помещения за месяц"),
        ("tobacco", "Darkside Distribution", 4800000, date(reference_year, reference_month, 3), 2, "Основная закупка табака и чаш"),
        ("barstock", "Metro Cash & Carry", 2600000, date(reference_year, reference_month, 7), 1, "Сиропы, лимонады и лёд"),
        ("supplies", "Local Partner", 950000, date(reference_year, reference_month, 10), 1, "Химия и расходники"),
        ("marketing", "Local Partner", 1800000, date(reference_year, reference_month, 12), 3, "Таргет и блогеры"),
        ("tobacco", "Darkside Distribution", 3200000, date(reference_year, reference_month, 17), 2, "Дозакупка топовых вкусов"),
        ("barstock", "Metro Cash & Carry", 1400000, date(reference_year, reference_month, 21), 1, "Фрукты и барная закупка"),
        ("supplies", "Local Partner", 700000, date(reference_year, reference_month, 25), 1, "Текстиль и уборка"),
    ]
    created = 0
    for category_code, supplier_title, amount_minor, expense_date, spread_months, comment in items:
        expense = Expense(
            venue_id=int(venue.id),
            category_id=int(categories[category_code].id),
            supplier_id=int(suppliers[supplier_title].id),
            payment_method_id=int(payment_methods["cashless"].id),
            amount_minor=int(amount_minor),
            expense_date=expense_date,
            generated_for_month=expense_date.replace(day=1),
            spread_months=int(spread_months),
            comment=comment,
            status="CONFIRMED",
            created_by_user_id=int(owner.id),
            created_at=datetime.combine(expense_date, time(11, 0), tzinfo=timezone.utc),
            updated_at=datetime.combine(expense_date, time(11, 5), tzinfo=timezone.utc),
        )
        db.add(expense)
        db.flush()
        rebuild_expense_allocations_for_expense(db=db, expense=expense)
        created += 1
    db.flush()
    return {"expenses": created}


def _create_pay_profiles(db: Session, *, venue: Venue, dictionaries: dict, users_by_key: dict[str, User], reference_year: int, reference_month: int) -> dict[str, int]:
    hookah_profile = PayProfile(venue_id=int(venue.id), title="Кальянный мастер", description="Почасовая ставка + % от зала + KPI", is_active=True)
    admin_profile = PayProfile(venue_id=int(venue.id), title="Администратор", description="Фикс за месяц + смены", is_active=True)
    bar_profile = PayProfile(venue_id=int(venue.id), title="Бар и зал", description="Почасовая ставка + фикс за смену", is_active=True)
    db.add_all([hookah_profile, admin_profile, bar_profile])
    db.flush()

    hookah_dept = dictionaries["departments"]["hookah"]
    kpi_upsale = dictionaries["kpis"]["upsale"]

    components = [
        PayComponent(venue_id=int(venue.id), pay_profile_id=int(hookah_profile.id), component_type="SALARY_HOURLY", title="Почасовая ставка", rate_minor=48000, is_active=True, sort_order=10),
        PayComponent(venue_id=int(venue.id), pay_profile_id=int(hookah_profile.id), component_type="PERCENT_DEPARTMENT_REVENUE", title="% от кальянного зала", percent_bps=320, department_id=int(hookah_dept.id), base_scope="WORKED_DATES", is_active=True, sort_order=20),
        PayComponent(venue_id=int(venue.id), pay_profile_id=int(hookah_profile.id), component_type="KPI_BONUS", title="Бонус за допродажи", amount_minor=350000, kpi_metric_id=int(kpi_upsale.id), threshold_value=12, is_active=True, sort_order=30),
        PayComponent(venue_id=int(venue.id), pay_profile_id=int(admin_profile.id), component_type="SALARY_FIXED_MONTH", title="Фикс за месяц", amount_minor=6500000, is_active=True, sort_order=10),
        PayComponent(venue_id=int(venue.id), pay_profile_id=int(admin_profile.id), component_type="SALARY_PER_SHIFT", title="Смена администратора", amount_minor=180000, is_active=True, sort_order=20),
        PayComponent(venue_id=int(venue.id), pay_profile_id=int(bar_profile.id), component_type="SALARY_HOURLY", title="Почасовая ставка", rate_minor=32000, is_active=True, sort_order=10),
        PayComponent(venue_id=int(venue.id), pay_profile_id=int(bar_profile.id), component_type="SALARY_PER_SHIFT", title="Фикс за смену", amount_minor=90000, is_active=True, sort_order=20),
    ]
    db.add_all(components)
    db.flush()

    profile_by_key = {
        "hookah": hookah_profile,
        "admin": admin_profile,
        "bar": bar_profile,
        "floor": bar_profile,
        "host": bar_profile,
    }
    created_assignments = 0
    month_start = _month_start(reference_year, reference_month)
    for spec in _build_demo_users():
        profile_key = spec.get("profile_key")
        if not profile_key:
            continue
        user = users_by_key[spec["key"]]
        profile = profile_by_key[profile_key]
        db.add(PayProfileAssignment(
            venue_id=int(venue.id),
            pay_profile_id=int(profile.id),
            member_user_id=int(user.id),
            start_date=month_start,
            end_date=None,
            is_active=True,
        ))
        created_assignments += 1
    db.flush()
    return {
        "pay_profiles": 3,
        "pay_components": len(components),
        "pay_profile_assignments": created_assignments,
    }


def _create_adjustments(db: Session, *, venue: Venue, users_by_key: dict[str, User], owner_user: User, reference_year: int, reference_month: int) -> dict[str, int]:
    items = [
        ("bonus", "staff_persona", date(reference_year, reference_month, 6), 120000, "Лучшие допродажи недели"),
        ("penalty", "aleksey_waiter", date(reference_year, reference_month, 11), 60000, "Опоздание на смену"),
        ("writeoff", None, date(reference_year, reference_month, 19), 95000, "Списание инвентаря"),
        ("bonus", "anna_admin", date(reference_year, reference_month, 28), 150000, "Хорошая оценка гостей по сервису"),
    ]
    for adj_type, member_key, adj_date, amount, reason in items:
        db.add(Adjustment(
            venue_id=int(venue.id),
            type=adj_type,
            member_user_id=int(users_by_key[member_key].id) if member_key else None,
            date=adj_date,
            amount=int(amount),
            reason=reason,
            is_active=True,
            created_by_user_id=int(owner_user.id),
            created_at=datetime.combine(adj_date, time(12, 0), tzinfo=timezone.utc),
            updated_by_user_id=int(owner_user.id),
            updated_at=datetime.combine(adj_date, time(12, 10), tzinfo=timezone.utc),
        ))
    db.flush()
    return {"adjustments": len(items)}


def _configure_billing(db: Session, *, venue: Venue, owner_user: User) -> dict[str, int]:
    state = get_or_create_billing_state(db, venue_id=int(venue.id))
    state.status = "ACTIVE"
    state.paid_until = datetime(2026, 4, 18, 12, 0, tzinfo=timezone.utc)
    state.grace_until = datetime(2026, 4, 21, 12, 0, tzinfo=timezone.utc)
    state.last_payment_at = datetime(2026, 3, 18, 11, 30, tzinfo=timezone.utc)
    state.next_payment_due_at = datetime(2026, 4, 18, 12, 0, tzinfo=timezone.utc)
    state.provider = "ROBOKASSA"
    state.updated_at = _utcnow()
    db.flush()

    tx = VenueBillingTransaction(
        venue_id=int(venue.id),
        source="MANUAL_ADMIN",
        type="EXTEND",
        status="SUCCEEDED",
        amount_minor=299000,
        days_added=30,
        period_from=datetime(2026, 3, 19, 0, 0, tzinfo=timezone.utc),
        period_until=datetime(2026, 4, 18, 12, 0, tzinfo=timezone.utc),
        provider_invoice_id="DEMO-EXTEND-1",
        provider_payment_id="DEMO-PAY-1",
        provider_payload_json={"demo": True},
        comment="Первое продление демо-заведения",
        created_by_user_id=int(owner_user.id),
        created_at=datetime(2026, 3, 19, 11, 30, tzinfo=timezone.utc),
        updated_at=datetime(2026, 3, 19, 11, 30, tzinfo=timezone.utc),
    )
    event = VenueBillingEvent(
        venue_id=int(venue.id),
        event_type="DEMO_BOOTSTRAP",
        old_status="ACTIVE",
        new_status="ACTIVE",
        meta_json={"paid_until": state.paid_until.isoformat() if state.paid_until else None},
        created_by_user_id=int(owner_user.id),
        created_at=datetime(2026, 3, 19, 11, 30, tzinfo=timezone.utc),
    )
    db.add_all([tx, event])
    db.flush()
    return {"billing_transactions": 1, "billing_events": 1}


def bootstrap_demo_venue(
    db: Session,
    *,
    venue_id: int | None = None,
    venue_name: str = DEFAULT_DEMO_VENUE_NAME,
    reference_year: int = DEFAULT_DEMO_REFERENCE_YEAR,
    reference_month: int = DEFAULT_DEMO_REFERENCE_MONTH,
    make_public: bool = True,
    export_fixture_path: str | None = None,
    export_fixture_after: bool = False,
) -> DemoBootstrapResult:
    warnings: list[str] = []
    counts: dict[str, int] = {}

    venue = _ensure_venue(
        db,
        venue_id=venue_id,
        venue_name=str(venue_name or DEFAULT_DEMO_VENUE_NAME).strip() or DEFAULT_DEMO_VENUE_NAME,
        reference_year=int(reference_year),
        reference_month=int(reference_month),
        make_public=bool(make_public),
    )

    deleted = clear_demo_venue_data(db, venue_id=int(venue.id))
    for key, value in deleted.items():
        if value:
            counts[f"deleted_{key}"] = int(value)

    users_by_key: dict[str, User] = {}
    positions_by_key: dict[str, VenuePosition] = {}
    for spec in _build_demo_users():
        user = _create_user(db, spec)
        users_by_key[spec["key"]] = user
        position = _create_member_and_position(db, venue=venue, user=user, spec=spec)
        if position is not None:
            positions_by_key[spec["key"]] = position
    counts["users"] = len(users_by_key)
    counts["venue_members"] = len(users_by_key)
    counts["venue_positions"] = len(positions_by_key)

    dictionaries = _create_dictionaries(db, venue=venue)
    counts["departments"] = len(dictionaries["departments"])
    counts["payment_methods"] = len(dictionaries["payment_methods"])
    counts["kpi_metrics"] = len(dictionaries["kpis"])
    counts["expense_categories"] = len(dictionaries["categories"])
    counts["suppliers"] = len(dictionaries["suppliers"])

    counts.update(_create_schedule(
        db,
        venue=venue,
        reference_year=int(reference_year),
        reference_month=int(reference_month),
        users_by_key=users_by_key,
        positions_by_key=positions_by_key,
        owner_user=users_by_key["owner"],
    ))
    counts.update(_create_reports(
        db,
        venue=venue,
        reference_year=int(reference_year),
        reference_month=int(reference_month),
        users_by_key=users_by_key,
        dictionaries=dictionaries,
    ))
    counts.update(_create_expenses(
        db,
        venue=venue,
        dictionaries=dictionaries,
        users_by_key=users_by_key,
        reference_year=int(reference_year),
        reference_month=int(reference_month),
    ))
    counts.update(_create_pay_profiles(db, venue=venue, dictionaries=dictionaries, users_by_key=users_by_key, reference_year=int(reference_year), reference_month=int(reference_month)))
    counts.update(_create_adjustments(
        db,
        venue=venue,
        users_by_key=users_by_key,
        owner_user=users_by_key["owner"],
        reference_year=int(reference_year),
        reference_month=int(reference_month),
    ))
    counts.update(_configure_billing(db, venue=venue, owner_user=users_by_key["owner"]))

    db.flush()
    try:
        calc = calculate_payroll_for_month(
            db=db,
            venue_id=int(venue.id),
            month=f"{int(reference_year):04d}-{int(reference_month):02d}",
            calculated_by_user_id=int(users_by_key["owner"].id),
        )
        counts["payroll_runs"] = 1
        counts["payroll_lines"] = len(calc.lines or [])
        counts["payroll_total_amount_minor"] = int(calc.run.total_amount_minor or 0) if getattr(calc, "run", None) is not None else 0
    except Exception as exc:  # pragma: no cover - best effort seed
        warnings.append(f"Payroll bootstrap skipped: {exc}")

    db.flush()
    fixture_path = None
    if export_fixture_after:
        fixture = export_demo_fixture(db, venue_id=int(venue.id), fixture_path=export_fixture_path)
        fixture_path = fixture.fixture_path
        counts["fixture_tables"] = len(fixture.counts or {})
        if fixture.warnings:
            warnings.extend(fixture.warnings)

    return DemoBootstrapResult(
        venue_id=int(venue.id),
        venue_name=str(venue.name or ""),
        reference_year=int(reference_year),
        reference_month=int(reference_month),
        fixture_path=fixture_path,
        counts=counts,
        warnings=warnings,
    )
