import {
  applyTelegramTheme,
  ensureLogin,
  mountCommonUI,
  mountNav,
  toast,
  api,
  getActiveVenueId,
  setActiveVenueId,
  getMyVenues,
} from "/app.js";

import { permSetFromResponse, roleUpper, canViewReports as canViewReportsPerms } from "/permissions.js";

applyTelegramTheme();
mountCommonUI("salary");

await ensureLogin({ silent: true });

const params = new URLSearchParams(location.search);

// preload venues once (used for: auto-pick active venue + show/hide "all venues" switch)
let __venues = [];
try { __venues = await getMyVenues().catch(() => []); } catch { __venues = []; }
const __venueIdOf = (v) => v?.venue?.id ?? v?.id ?? v?.venue_id ?? v?.venueId ?? v?.venueID ?? v?.venue?.venue_id ?? null;
const __venueNameOf = (id) => {
  if (id == null) return "";
  const sid = String(id);
  const v = (__venues || []).find((x) => String(__venueIdOf(x)) === sid || String(__venueIdOf(x?.venue)) === sid);
  const nested = v?.venue || null;
  return (
    v?.name ??
    v?.venue_name ??
    v?.title ??
    nested?.name ??
    nested?.venue_name ??
    nested?.title ??
    ""
  );
};


async function ensureVenuesLoaded() {
  if (Array.isArray(__venues) && __venues.length) return __venues;
  try { __venues = await getMyVenues().catch(() => []); } catch { __venues = []; }
  return __venues;
}

let venueId = params.get("venue_id") || getActiveVenueId();
if (!venueId && Array.isArray(__venues) && __venues.length) {
  const id0 = __venueIdOf(__venues[0]);
  if (id0 != null) venueId = String(id0);
}
if (venueId) setActiveVenueId(venueId);

// scope mode (venue vs all); allow "all" only if user has 2+ venues
let scopeMode = (params.get("scope") || "venue").toLowerCase();
if (scopeMode !== "all") scopeMode = "venue";
if (!Array.isArray(__venues) || __venues.length < 2) scopeMode = "venue";

// Determine whether user has report access for this venue (affects navbar layout)
let __canReports = false;
try {
  if (venueId) {
    const pr = await api(`/me/venues/${encodeURIComponent(venueId)}/permissions`);
    const pset = permSetFromResponse(pr);
    const role = roleUpper(pr);
    __canReports = canViewReportsPerms(pset, role, "");
  }
} catch {}

await mountNav({ activeTab: (__canReports ? "finance" : "salary") });

const el = {
  monthLabel: document.getElementById("monthLabel"),
  prev: document.getElementById("monthPrev"),
  next: document.getElementById("monthNext"),
  sumSalary: document.getElementById("sumSalary"),
  sumTips: document.getElementById("sumTips"),
  sumPenalties: document.getElementById("sumPenalties"),
  sumBonuses: document.getElementById("sumBonuses"),
  rowWriteoffs: document.getElementById("rowWriteoffs"),
  sumWriteoffs: document.getElementById("sumWriteoffs"),
  sumTotal: document.getElementById("sumTotal"),
  daysList: document.getElementById("daysList"),
  monthChart: document.getElementById("monthChart"),
  btnThisVenue: document.getElementById("btnThisVenue"),
  btnAllVenues: document.getElementById("btnAllVenues"),
  sourceHint: document.getElementById("salarySourceHint"),
  payrollBreakdownRow: document.getElementById("payrollBreakdownRow"),
  openPayrollBreakdownBtn: document.getElementById("openPayrollBreakdownBtn"),
};

const allEls = {
  card: document.getElementById("allVenuesCard"),
  count: document.getElementById("allVenuesCount"),
  hint: document.getElementById("allVenuesHint"),
  earned: document.getElementById("allEarned"),
  tips: document.getElementById("allTips"),
  bonuses: document.getElementById("allBonuses"),
  penalties: document.getElementById("allPenalties"),
  net: document.getElementById("allNet"),
  list: document.getElementById("allVenuesList"),
};

function setScopeMode(next) {
  scopeMode = (next === "all") ? "all" : "venue";

  if (el.btnThisVenue) el.btnThisVenue.disabled = (scopeMode === "venue");
  if (el.btnAllVenues) el.btnAllVenues.disabled = (scopeMode === "all");

  if (allEls.card) allEls.card.style.display = (scopeMode === "all") ? "" : "none";

  const vs = document.getElementById("venueScopeWrap");
  if (vs) vs.style.display = (scopeMode === "all") ? "none" : "";

  // keep URL in sync without reload
  try {
    const p = new URLSearchParams(location.search);
    if (scopeMode === "all") p.set("scope", "all"); else p.delete("scope");
    history.replaceState(null, "", `${location.pathname}?${p.toString()}`);
  } catch {}
}

// Hide "All venues" switch if user has only one venue
try {
  const scope = document.getElementById("salaryScope");
  if (scope && (!Array.isArray(__venues) || __venues.length < 2)) scope.style.display = "none";
} catch {}

setScopeMode(scopeMode);

el.btnThisVenue?.addEventListener("click", () => { setScopeMode("venue"); refresh(); });
el.btnAllVenues?.addEventListener("click", () => { setScopeMode("all"); refresh(); });

function ensureModal() {
  let m = document.getElementById("modal");
  if (!m) {
    m = document.createElement("div");
    m.id = "modal";
    m.className = "modal";
    m.innerHTML = `
      <div class="modal__backdrop" data-close></div>
      <div class="modal__panel">
        <div class="modal__head row row--between ai-center">
          <div>
            <div class="modal__title">День</div>
            <div class="muted small" id="modalSubtitle"></div>
          </div>
          <button class="btn sm" data-close aria-label="Закрыть">✕</button>
        </div>
        <div class="modal__body"></div>
      </div>
    `;
    document.body.appendChild(m);
  }
  // Bind close handlers once
  if (!m.__bound) {
    const close = () => m.classList.remove("open");
    m.querySelectorAll("[data-close]").forEach((x) => x.addEventListener("click", close));
    m.__bound = true;
  }
  return m;
}

const modal = ensureModal();
const modalTitle = modal?.querySelector(".modal__title");
const modalBody = modal?.querySelector(".modal__body");
const modalSubtitleEl = document.getElementById("modalSubtitle");
function closeModal() { modal?.classList.remove("open"); }
function openModal(title, subtitle, bodyHtml) {
  if (modalTitle) modalTitle.textContent = title || "День";
  if (modalSubtitleEl) modalSubtitleEl.textContent = subtitle || "";
  if (modalBody) modalBody.innerHTML = bodyHtml || "";
  modal?.classList.add("open");
}

function pad2(n) { return String(n).padStart(2, "0"); }
function ym(d) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}`; }
let curMonth = new Date(); curMonth.setDate(1);

// allow ?month=YYYY-MM
const qMonth = params.get("month");
if (qMonth && /^\d{4}-\d{2}$/.test(qMonth)) {
  const [yy, mm] = qMonth.split("-").map((x) => parseInt(x, 10));
  if (yy && mm) curMonth = new Date(yy, mm - 1, 1);
}

function syncUrl() {
  try {
    const p = new URLSearchParams(location.search);
    p.set("month", ym(curMonth));
    if (venueId) p.set("venue_id", String(venueId));
    history.replaceState(null, "", `${location.pathname}?${p.toString()}`);
  } catch {}
}

function monthTitle(d) {
  const m = d.toLocaleString("ru-RU", { month: "long" });
  return `${m[0].toUpperCase()}${m.slice(1)} ${d.getFullYear()}`;
}
function formatMoney(x) {
  const n = Number(x);
  if (!Number.isFinite(n)) return "0";
  return Math.round(n).toString();
}
function formatMoneyMinor(x) {
  const n = Number(x || 0) / 100;
  if (!Number.isFinite(n)) return "0";
  return n.toLocaleString("ru-RU", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function esc(s){
  return String(s ?? "")
    .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

let shifts = [];
let days = []; // [{date, salary, hasReport, shifts:[] }]
let adjustments = []; // month items
let monthSummaryItem = null;
let payrollLine = null;

async function loadMonth() {
  if (!venueId) {
    const m = ym(curMonth);
    if (el.monthLabel) el.monthLabel.textContent = monthTitle(curMonth);
    if (el.daysList) el.daysList.innerHTML = `<div class="muted">Нет активного заведения</div>`;
    if (el.monthChart) el.monthChart.innerHTML = `<div class="muted">Нет активного заведения</div>`;
    return;
  }

  const m = ym(curMonth);
  el.monthLabel.textContent = monthTitle(curMonth);
  if (el.daysList) el.daysList.innerHTML = `<div class="skeleton"></div><div class="skeleton"></div>`;
  try {
    const out = await api(`/venues/${encodeURIComponent(venueId)}/shifts?month=${encodeURIComponent(m)}`);
    shifts = Array.isArray(out) ? out : (out?.items || []);
  } catch (e) {
    shifts = [];
    toast(e?.message || "Не удалось загрузить смены", "err");
  }

  try {
    const adj = await api(`/venues/${encodeURIComponent(venueId)}/adjustments?month=${encodeURIComponent(m)}&mine=1`);
    adjustments = Array.isArray(adj?.items) ? adj.items : [];
  } catch {
    adjustments = [];
  }

  monthSummaryItem = null;
  payrollLine = null;
  try {
    const summary = await api(`/me/salary-summary?month=${encodeURIComponent(m)}`);
    const items = Array.isArray(summary?.items) ? summary.items : [];
    monthSummaryItem = items.find((item) => String(item?.venue?.id ?? item?.venue_id ?? item?.venueId ?? "") === String(venueId)) || null;
    if (monthSummaryItem?.source === "payroll") {
      payrollLine = await api(`/me/payroll-line?month=${encodeURIComponent(m)}&venue_id=${encodeURIComponent(venueId)}`).catch(() => null);
    }
  } catch {
    monthSummaryItem = null;
    payrollLine = null;
  }

  // group by date
  const map = new Map(); // date -> {salary, hasReport, shifts:[]}
  for (const s of shifts) {
    const d = s.date;
    if (!d) continue;
    const row = map.get(d) || { date: d, salary: 0, hasReport: !!s.report_exists, shifts: [] };
    row.hasReport = row.hasReport || !!s.report_exists;
    row.shifts.push(s);

    const val = Number(s.my_salary);
    if (Number.isFinite(val)) row.salary += val;

    const tip = Number(s.my_tips_share);
    if (!Number.isFinite(row.tips)) row.tips = 0;
    if (Number.isFinite(tip)) row.tips += tip;

    map.set(d, row);
  }

  days = Array.from(map.values()).sort((a,b)=>a.date.localeCompare(b.date));

  renderSummary();
  renderMonthChart();
  renderDays();
}



async function loadMonthAll() {
  await ensureVenuesLoaded();
  if (!allEls.list) return;

  const m = ym(curMonth);
  el.monthLabel.textContent = monthTitle(curMonth);

  const skeleton = `<div class="card"><div class="skeleton"></div></div><div class="card"><div class="skeleton"></div></div>`;
  allEls.list.innerHTML = skeleton;

  const fmt = (n) => Math.round(Number(n || 0)).toLocaleString("ru-RU");
  const vIdOf = (v) => {
    const raw = v?.venue;
    if (typeof raw === "number") return raw;
    if (typeof raw === "string") {
      const t = raw.trim();
      if (t && !Number.isNaN(Number(t))) return Number(t);
    }
    return (
      v?.venue?.id ??
      v?.venue_id ??
      v?.venueId ??
      v?.venueID ??
      v?.id ??
      v?.venue?.venue_id ??
      null
    );
  };
  const vNameOf = (v) => {
    const raw = v?.venue;
    if (typeof raw === "string") {
      const t = raw.trim();
      if (t && Number.isNaN(Number(t))) return t;
    }
    return (
      v?.venue?.name ??
      v?.venue?.title ??
      v?.venue_name ??
      v?.venueName ??
      v?.name ??
      v?.title ??
      __venueNameOf(vIdOf(v))
    );
  };

  let totals = null;
  let items = null;

  // 1) Try server-side summary first (fast, if backend supports it)
  try {
    const data = await api(`/me/salary-summary?month=${encodeURIComponent(m)}`);

    totals =
      (data && typeof data === "object" && (data.totals || data.total || data.summary)) || null;

    items =
      (Array.isArray(data?.venues) ? data.venues : null) ||
      (Array.isArray(data?.items) ? data.items : null) ||
      (Array.isArray(data?.by_venues) ? data.by_venues : null) ||
      (Array.isArray(data?.byVenues) ? data.byVenues : null) ||
      (Array.isArray(data?.per_venue) ? data.per_venue : null) ||
      (Array.isArray(data?.perVenue) ? data.perVenue : null) ||
      (Array.isArray(data?.venues_summary) ? data.venues_summary : null) ||
      null;
  } catch {
    totals = null;
    items = null;
  }

  // 2) Fallback: if backend doesn't return per-venue list — compute on client from shifts+adjustments.
  // Works reliably and matches the per-venue page logic.
  if ((!items || !items.length) && Array.isArray(__venues) && __venues.length) {
    items = [];
    const agg = { earned: 0, tips: 0, bonuses: 0, penalties: 0, net: 0 };

    for (const v of __venues) {
      const vid = vIdOf(v);
      if (vid == null) continue;

      const name = vNameOf(v) || `#${vid}`;

      let shifts = [];
      try {
        const out = await api(`/venues/${encodeURIComponent(String(vid))}/shifts?month=${encodeURIComponent(m)}`);
        shifts = Array.isArray(out) ? out : (out?.items || []);
      } catch {
        shifts = [];
      }

      let adjs = [];
      try {
        const adj = await api(`/venues/${encodeURIComponent(String(vid))}/adjustments?month=${encodeURIComponent(m)}&mine=1`);
        adjs = Array.isArray(adj?.items) ? adj.items : [];
      } catch {
        adjs = [];
      }

      const earned = shifts.reduce((a, s) => a + (Number(s?.my_salary) || 0), 0);
      const tips = shifts.reduce((a, s) => a + (Number(s?.my_tips_share) || 0), 0);
      const bonuses = adjs.filter(x => x?.type === "bonus").reduce((a, x) => a + (Number(x?.amount) || 0), 0);
      const penalties = adjs
        .filter(x => x?.type === "penalty" || x?.type === "writeoff")
        .reduce((a, x) => a + (Number(x?.amount) || 0), 0);

      const net = earned - penalties + bonuses;

      // include venue row even if zeros (user expects a list by venues)
      items.push({
        venue_id: vid,
        venue_name: name,
        earned,
        tips,
        bonuses,
        penalties,
        net,
      });

      agg.earned += earned;
      agg.tips += tips;
      agg.bonuses += bonuses;
      agg.penalties += penalties;
      agg.net += net;
    }

    totals = agg;
  }

  // Normalize totals
  const t = totals || {};
  if (allEls.earned) allEls.earned.textContent = fmt(t.earned ?? t.salary ?? t.total_salary);
  if (allEls.tips) allEls.tips.textContent = fmt(t.tips ?? t.total_tips);
  if (allEls.bonuses) allEls.bonuses.textContent = fmt(t.bonuses ?? t.total_bonuses);
  if (allEls.penalties) allEls.penalties.textContent = fmt(t.penalties ?? t.total_penalties ?? t.penalties_total);
  if (allEls.net) allEls.net.textContent = fmt(t.net ?? t.total ?? t.total_net);

  const safeItems = Array.isArray(items) ? items : [];
  if (allEls.count) allEls.count.textContent = safeItems.length ? `${safeItems.length} завед.` : "—";
  if (allEls.hint) allEls.hint.textContent = safeItems.length ? "" : "Нет данных";

  if (!safeItems.length) {
    allEls.list.innerHTML = `<div class="muted">Нет данных за выбранный месяц</div>`;
    return;
  }

  // Sort: highest net first (more useful)
  safeItems.sort((a, b) => (Number(b?.net) || 0) - (Number(a?.net) || 0));

  allEls.list.innerHTML = safeItems.map((v) => {
    const vid = vIdOf(v);
    const name = esc(vNameOf(v) || (vid != null ? __venueNameOf(vid) : "") || `#${vid ?? ""}`);
    const earned = Number(v?.earned ?? v?.salary ?? v?.total_salary ?? v?.total_earned ?? 0);
    const tips = Number(v?.tips ?? v?.total_tips ?? 0);
    const bonuses = Number(v?.bonuses ?? v?.total_bonuses ?? 0);
    const penalties = Number(v?.penalties ?? v?.total_penalties ?? v?.penalties_total ?? v?.total_penalty ?? 0);
    const net = Number(v?.net ?? v?.total ?? v?.total_net ?? (earned - penalties + bonuses) ?? 0);

    return `
      <div class="card">
        <div class="row row--between ai-center" style="gap:8px; flex-wrap:wrap;">
          <b>${name}</b>
          ${v?.source === "payroll" ? `<span class="badge">payroll</span>` : ""}
        </div>

        <div class="grid mt-10 salary-all-kpis">
          <div class="mini-kpi">
            <div class="muted small">Начислено</div>
            <b>${fmt(earned)}</b>
          </div>

          <div class="mini-kpi">
            <div class="muted small">Чаевые</div>
            <b>${fmt(tips)}</b>
          </div>

          <div class="mini-kpi">
            <div class="muted small">Премии</div>
            <b>${fmt(bonuses)}</b>
          </div>

          <div class="mini-kpi">
            <div class="muted small">Штрафы/Списания</div>
            <b>${fmt(penalties)}</b>
          </div>

          <div class="mini-kpi total">
            <div class="muted small">Итого</div>
            <b>${fmt(net)}</b>
          </div>
        </div>
      </div>`;
  }).join("");
}

async function refresh() {
  // Update scope UI + cards
  setScopeMode(scopeMode);

  if (scopeMode === "all") {
    if (el.daysList) el.daysList.innerHTML = "";
    await loadMonthAll();
    return;
  }
  await loadMonth();
}

function formatDateRuNoG(iso) {
  const dt = new Date(String(iso).length === 10 ? iso + "T00:00:00" : iso);
  const dd = String(dt.getDate()).padStart(2, "0");
  const mm = String(dt.getMonth() + 1).padStart(2, "0");
  const yyyy = dt.getFullYear();
  return `${dd}.${mm}.${yyyy}`;
}

function renderSummary() {
  const legacySalary = days.reduce((acc, d) => acc + (Number.isFinite(d.salary) ? d.salary : 0), 0);
  const legacyTips = days.reduce((acc, d) => acc + (Number.isFinite(d.tips) ? d.tips : 0), 0);

  const totalPenalties = adjustments.filter(x => x.type === "penalty").reduce((a,x)=>a+Number(x.amount||0),0);
  const totalBonuses = adjustments.filter(x => x.type === "bonus").reduce((a,x)=>a+Number(x.amount||0),0);

  const holdWriteoffs = false;
  const totalWriteoffs = adjustments.filter(x => x.type === "writeoff").reduce((a,x)=>a+Number(x.amount||0),0);

  const earned = Number(monthSummaryItem?.earned ?? legacySalary ?? 0);
  const tips = Number(monthSummaryItem?.tips ?? legacyTips ?? 0);
  const bonuses = Number(monthSummaryItem?.bonuses ?? totalBonuses ?? 0);
  const penalties = Number(monthSummaryItem?.penalties ?? totalPenalties ?? 0);
  const total = Number(monthSummaryItem?.net ?? (earned + tips - penalties + bonuses - (holdWriteoffs ? totalWriteoffs : 0)) ?? 0);

  el.sumSalary.textContent = formatMoney(earned);
  el.sumTips.textContent = formatMoney(tips);
  el.sumPenalties.textContent = formatMoney(penalties);
  el.sumBonuses.textContent = formatMoney(bonuses);

  if (holdWriteoffs) {
    el.rowWriteoffs.style.display = "flex";
    el.sumWriteoffs.textContent = formatMoney(totalWriteoffs);
  } else {
    el.rowWriteoffs.style.display = "none";
  }

  el.sumTotal.textContent = formatMoney(total);

  if (el.sourceHint) {
    if (monthSummaryItem?.source === "payroll") {
      el.sourceHint.textContent = "Итог за месяц взят из нового payroll-расчёта. Блок «По дням» пока остаётся справочным и показывает смены отдельно.";
    } else if (monthSummaryItem?.source === "legacy") {
      el.sourceHint.textContent = "Итог за месяц пока считается по старой shift-логике. Для этого заведения payroll ещё не назначен или не рассчитан.";
    } else {
      el.sourceHint.textContent = "";
    }
  }
  if (el.payrollBreakdownRow) el.payrollBreakdownRow.style.display = (monthSummaryItem?.source === "payroll" && payrollLine?.breakdown) ? "flex" : "none";
}

function openPayrollBreakdown() {
  if (!payrollLine?.breakdown) return;
  const breakdown = payrollLine.breakdown || {};
  const metrics = breakdown.metrics || {};
  const components = Array.isArray(breakdown.components) ? breakdown.components : [];
  const componentsHtml = components.length ? components.map((c) => `
    <div class="section">
      <div class="row row--between" style="gap:12px; align-items:flex-start;">
        <div>
          <b>${esc(c.title || c.component_type || "Компонент")}</b>
          <div class="muted small mt-4">${esc(String(c.component_type || ""))}</div>
        </div>
        <div><b>${esc(formatMoneyMinor(c.amount_minor || 0))}</b></div>
      </div>
    </div>
  `).join("") : `<div class="muted">Нет breakdown</div>`;

  openModal(
    `Начисление за ${ym(curMonth)}`,
    breakdown.pay_profile_title ? `Профиль: ${breakdown.pay_profile_title}` : "",
    `<div class="itemcard" style="margin-top:12px">
      <div class="row" style="justify-content:space-between; align-items:center; gap:12px;">
        <div class="muted">Итого начислено</div>
        <div class="day-salary">${esc(formatMoneyMinor(payrollLine.amount_minor || 0))}</div>
      </div>
      <div class="muted small mt-8">Часы: ${esc(metrics.hours_total ?? 0)} · Смены: ${esc(metrics.shifts_count ?? 0)} · Дней: ${esc(metrics.worked_dates_count ?? 0)}</div>
      <div style="margin-top:10px">${componentsHtml}</div>
    </div>`
  );
}

function renderMonthChart() {
  if (!el.monthChart) return;
  if (!days.length) {
    if (el.monthChart) el.monthChart.innerHTML = `<div class="muted">Нет данных за этот месяц</div>`;
    return;
  }

  const maxVal = Math.max(1, ...days.map(d => Math.max(0, Number(d.salary) || 0)));
  const bars = days.map((d) => {
    const dt = new Date(String(d.date).length === 10 ? d.date + "T00:00:00" : d.date);
    const label = String(dt.getDate());
    const val = Math.max(0, Number(d.salary) || 0);
    let h = Math.round((val / maxVal) * 100);
    if (!h && d.hasReport) h = 8; // show a small stub if report exists but salary is 0
    const barColor = d.hasReport ? "var(--accent)" : "var(--borderSoft)";
    return `
      <button class="bar" type="button" data-date="${esc(d.date)}" style="--h:${h}%;--barColor:${barColor}">
        <div class="bar__track"><div class="bar__fill"></div></div>
        <div class="bar__label">${esc(label)}</div>
      </button>
    `;
  }).join("");

  if (el.monthChart) el.monthChart.innerHTML = `<div class="chart__bars">${bars}</div>`;
  el.monthChart.querySelectorAll(".bar").forEach((btn) => {
    const date = btn.getAttribute("data-date");
    const d = days.find(x => x.date === date);
    if (!d) return;
    btn.addEventListener("click", () => openDayModal(d));
  });
}


function renderDays() {
  if (el.daysList) el.daysList.innerHTML = "";
  if (!days.length) {
    if (el.daysList) el.daysList.innerHTML = `<div class="muted">Нет данных за этот месяц</div>`;
    return;
  }

  for (const d of days) {
    const card = document.createElement("div");
    const dd = formatDateRuNoG(d.date); // <-- "dd.mm.yyyy"
    card.className = "list__row";

    card.innerHTML = `
      <div class="row row--between">
        <div>
          <b>${esc(dd)}</b>
        </div>
        <div class="dayrow__right">
          <div class="day-salary ${d.salary>0 ? "" : "day-salary--muted"}">${d.salary>0 ? ("+"+formatMoney(d.salary)) : "Нет отчета"}</div>
          <button class="btn" data-open>Подробнее</button>
        </div>
      </div>
    `;
    card.querySelector("[data-open]").addEventListener("click", () => openDayModal(d));
    if (el.daysList) el.daysList.appendChild(card);
  }
}

function openDayModal(d) {
  const shiftsHtml = (d.shifts || []).map(s => {
    const interval = s.interval?.title || s.interval_title || s.interval?.id || "Смена";
    const sal = Number(s.my_salary);
    const salText = Number.isFinite(sal) ? ("+"+formatMoney(sal)) : "—";
    return `
      <div class="section">
        <div class="row row--between">
          <div>
            <b>${esc(interval)}</b>
            <div class="muted small">${s.report_exists ? "Отчёт есть" : "Нет отчёта"}</div>
          </div>
          <div class="day-salary" style="${Number.isFinite(sal) ? "" : "opacity:.45"}">${esc(salText)}</div>
        </div>
      </div>
    `;
  }).join("");

  openModal(
    `${formatDateRuNoG(d.date)}`,
    "",
    `<div class="itemcard" style="margin-top:12px">
        <div class="row" style="justify-content:space-between;align-items:center">
          <div class="muted">Итого за день</div>
          <div class="day-salary ${d.salary>0 ? "" : "day-salary--muted"}">${d.salary>0 ? ("+"+formatMoney(d.salary)) : "—"}</div>
        </div>
        <div class="row" style="justify-content:space-between;align-items:center; margin-top:6px">
          <div class="muted">Чаевые</div>
          <div class="day-salary">${formatMoney(d.tips || 0)}</div>
        </div>
        <div style="margin-top:10px">${shiftsHtml || `<div class="muted">Смен нет</div>`}</div>
      </div>`
  );
}

el.prev.addEventListener("click", async () => {
  curMonth.setMonth(curMonth.getMonth() - 1);
  curMonth.setDate(1);
  syncUrl();
  await refresh();
});
el.next.addEventListener("click", async () => {
  curMonth.setMonth(curMonth.getMonth() + 1);
  curMonth.setDate(1);
  syncUrl();
  await refresh();
});

el.openPayrollBreakdownBtn?.addEventListener("click", openPayrollBreakdown);

syncUrl();
refresh();
