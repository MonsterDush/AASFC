import {
  applyTelegramTheme,
  ensureLogin,
  mountNav,
  mountCommonUI,
  toast,
  confirmModal,
  setActiveVenueId,
  getMyVenuePermissions,
  getDepartments,
  createDepartment,
  updateDepartment,
} from "/app.js";

const root = document.getElementById("root");

function esc(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function parseVenueId() {
  const params = new URLSearchParams(location.search);
  const id = params.get("venue_id") || "";
  if (id) setActiveVenueId(id);
  return id;
}

function has(perms, code) {
  const arr = perms?.permissions;
  return Array.isArray(arr) && arr.includes(code);
}

function isOwner(perms) {
  return String(perms?.role || "").toUpperCase() === "OWNER";
}

function renderShell() {
  root.innerHTML = `
    <div class="topbar">
      <div class="brand">
        <div class="logo"></div>
        <div class="title">
          <b id="title">Департаменты</b>
          <div class="muted">структура выручки</div>
        </div>
      </div>
      <div class="userpill" data-userpill>…</div>
    </div>

    <div class="card">
      <div class="muted">Создайте департаменты (например: Кальян, Бар, Кухня). Они будут использоваться в отчётах и зарплатах.</div>

      <div class="itemcard" style="margin-top:12px">
        <div class="section-head">
          <div class="section-title">
            <b>Список департаментов</b>
          </div>
            <div class="section-actions">
              <button class="btn primary" id="btnCreate">+ Добавить</button>
            </div>
          
        </div>
        <div class="section-actions">
          <label class="chk">
            <input type="checkbox" id="showArchived" />
            <span class="muted">Показывать архив</span>
          </label>
        </div>

        <div id="list" style="margin-top:10px">
          <div class="skeleton"></div><div class="skeleton"></div>
        </div>
      </div>

      <div class="row" style="margin-top:12px">
        <a class="link" id="back" href="#">← Назад к заведению</a>
      </div>
    </div>

    <div id="toast" class="toast"><div class="toast__text"></div></div>

    <!-- confirm modal (используется confirmModal()) -->
    <div id="modal" class="modal">
      <div class="modal__backdrop"></div>
      <div class="modal__panel">
        <div class="modal__head">
          <div class="modal__title">Подтверждение</div>
          <button class="btn" data-close>Закрыть</button>
        </div>
        <div class="modal__body"></div>
      </div>
    </div>

    <!-- editor modal -->
    <div id="editModal" class="modal">
      <div class="modal__backdrop" data-close></div>
      <div class="modal__panel">
        <div class="modal__head">
          <div>
            <b class="modal__title" id="editTitle">Департамент</b>
            <div class="muted" id="editHint" style="margin-top:4px; font-size:12px"></div>
          </div>
          <button class="btn" data-close>Закрыть</button>
        </div>
        <div class="modal__body" id="editBody"></div>
      </div>
    </div>

    <div class="nav">
      <div class="wrap"><div id="nav"></div></div>
    </div>
  `;

  mountCommonUI("none");
}

function openEditModal({ title, hint, bodyHtml }) {
  const m = document.getElementById("editModal");
  const t = document.getElementById("editTitle");
  const h = document.getElementById("editHint");
  const b = document.getElementById("editBody");
  if (t) t.textContent = title || "Департамент";
  if (h) h.textContent = hint || "";
  if (b) b.innerHTML = bodyHtml || "";
  m?.classList.add("open");
}

function closeEditModal() {
  document.getElementById("editModal")?.classList.remove("open");
}

function wireEditModalClose() {
  const m = document.getElementById("editModal");
  if (!m) return;
  m.querySelectorAll("[data-close]").forEach((x) => x.addEventListener("click", closeEditModal));
}

let state = {
  venueId: "",
  perms: null,
  items: [],
  includeArchived: false,
  can: { view: false, create: false, edit: false, archive: false },
};

function computeCaps(perms) {
  const owner = isOwner(perms);
  return {
    view: owner || has(perms, "DEPARTMENTS_VIEW"),
    create: owner || has(perms, "DEPARTMENTS_CREATE"),
    edit: owner || has(perms, "DEPARTMENTS_EDIT"),
    archive: owner || has(perms, "DEPARTMENTS_ARCHIVE"),
  };
}

function renderList() {
  const el = document.getElementById("list");
  if (!el) return;

  if (!state.can.view) {
    el.innerHTML = `<div class="muted">Нет доступа</div>`;
    return;
  }

  if (!state.items.length) {
    el.innerHTML = `<div class="muted">Пока пусто</div>`;
    return;
  }

  el.innerHTML = "";
  for (const it of state.items) {
    const row = document.createElement("div");
    row.className = "listrow";

    const left = document.createElement("div");
    left.className = "listrow__left";
    left.innerHTML = `
      <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap">
        <b>${esc(it.title)}</b>
        ${it.is_active ? "" : `<span class=\"badge\">архив</span>`}
      </div>
      <div class="mono muted listrow__meta">code=${esc(it.code)} · sort=${esc(it.sort_order)}</div>
    `;

    const right = document.createElement("div");
    right.className = "row row--nowrap";
    right.style = "gap:8px; flex:0 0 auto;";

    if (state.can.edit) {
      const btnEdit = document.createElement("button");
      btnEdit.className = "btn sm";
      btnEdit.textContent = "Редакт.";
      btnEdit.onclick = () => openEditor({ mode: "edit", item: it });
      right.appendChild(btnEdit);
    }

    if (state.can.archive) {
      const btn = document.createElement("button");
      btn.className = "btn sm" + (it.is_active ? " danger" : "");
      btn.textContent = it.is_active ? "В архив" : "Вернуть";
      btn.onclick = async () => {
        const ok = await confirmModal({
          title: it.is_active ? "Архивировать департамент?" : "Восстановить департамент?",
          text: `${it.is_active ? "Убрать" : "Вернуть"} "${it.title}"?`,
          confirmText: it.is_active ? "В архив" : "Вернуть",
          danger: it.is_active,
        });
        if (!ok) return;
        try {
          await updateDepartment(state.venueId, it.id, { is_active: !it.is_active });
          toast("Готово", "ok");
          await load();
        } catch (e) {
          toast("Ошибка: " + e.message, "err");
        }
      };
      right.appendChild(btn);
    }

    row.appendChild(left);
    row.appendChild(right);
    el.appendChild(row);
  }
}

function editorForm({ mode, item }) {
  const it = item || {};
  const isEdit = mode === "edit";
  const activeChecked = (isEdit ? !!it.is_active : true) ? "checked" : "";

  return `
    <div class="grid grid2" style="margin-top:10px">
      <div>
        <div class="muted" style="margin-bottom:6px">Код (slug)</div>
        <input id="f_code" placeholder="hookah" value="${esc(it.code || "")}" ${isEdit ? "" : ""} />
        <div class="muted" style="margin-top:6px; font-size:12px">Латиница/цифры/дефисы. Например: hookah, bar, kitchen</div>
      </div>
      <div>
        <div class="muted" style="margin-bottom:6px">Название</div>
        <input id="f_title" placeholder="Кальян" value="${esc(it.title || "")}" />
      </div>
      <div>
        <div class="muted" style="margin-bottom:6px">Порядок</div>
        <input id="f_sort" inputmode="numeric" placeholder="0" value="${esc(it.sort_order ?? 0)}" />
      </div>
      <div>
        <div class="muted" style="margin-bottom:6px">Статус</div>
        <label class="row" style="gap:8px; align-items:center">
          <input type="checkbox" id="f_active" ${activeChecked} />
          <span>Активен</span>
        </label>
      </div>
    </div>

    <div class="row" style="margin-top:12px; justify-content:flex-end; gap:8px">
      <button class="btn" id="btnCancel" type="button">Отмена</button>
      <button class="btn primary" id="btnSave" type="button">Сохранить</button>
    </div>
  `;
}

function wireEditor({ mode, item }) {
  document.getElementById("btnCancel")?.addEventListener("click", closeEditModal);
  document.getElementById("btnSave")?.addEventListener("click", async () => {
    const code = document.getElementById("f_code")?.value?.trim();
    const title = document.getElementById("f_title")?.value?.trim();
    const sort = document.getElementById("f_sort")?.value;
    const is_active = !!document.getElementById("f_active")?.checked;

    if (!code) return toast("Укажи код", "err");
    if (!title) return toast("Укажи название", "err");

    const payload = {
      code,
      title,
      sort_order: Number(sort || 0),
      is_active,
    };

    try {
      if (mode === "create") {
        await createDepartment(state.venueId, payload);
      } else {
        await updateDepartment(state.venueId, item.id, payload);
      }
      closeEditModal();
      toast("Сохранено", "ok");
      await load();
    } catch (e) {
      toast("Ошибка: " + e.message, "err");
    }
  });
}

function openEditor({ mode, item }) {
  if (mode === "create" && !state.can.create) {
    toast("Нет прав на создание", "err");
    return;
  }
  if (mode === "edit" && !state.can.edit) {
    toast("Нет прав на редактирование", "err");
    return;
  }

  openEditModal({
    title: mode === "create" ? "Новый департамент" : "Департамент",
    hint: mode === "create" ? "Добавь департамент, который будет использоваться в отчётах" : "Редактирование департамента",
    bodyHtml: editorForm({ mode, item }),
  });
  wireEditor({ mode, item });
}

async function load() {
  const listEl = document.getElementById("list");
  if (listEl) listEl.innerHTML = `<div class="skeleton"></div><div class="skeleton"></div>`;

  if (!state.can.view) {
    state.items = [];
    renderList();
    return;
  }

  try {
    const items = await getDepartments(state.venueId, { includeArchived: state.includeArchived });
    state.items = Array.isArray(items) ? items : [];
  } catch (e) {
    state.items = [];
    toast("Ошибка загрузки: " + e.message, "err");
  }

  renderList();
}

(async () => {
  applyTelegramTheme();
  renderShell();

  await ensureLogin({ silent: true });

  state.venueId = parseVenueId();
  if (!state.venueId) {
    location.replace("/app-venues.html");
    return;
  }

  await mountNav({ activeTab: "venue", requireVenue: true });

  // back link
  const back = document.getElementById("back");
  if (back) back.href = `/app-venue.html?venue_id=${encodeURIComponent(state.venueId)}`;

  try {
    state.perms = await getMyVenuePermissions(state.venueId);
  } catch {
    state.perms = null;
  }
  state.can = computeCaps(state.perms);

  // create button gating
  const btnCreate = document.getElementById("btnCreate");
  if (btnCreate) {
    btnCreate.style.display = state.can.create ? "" : "none";
    btnCreate.onclick = () => openEditor({ mode: "create" });
  }

  // archived toggle
  const chk = document.getElementById("showArchived");
  if (chk) {
    chk.checked = false;
    chk.onchange = async () => {
      state.includeArchived = !!chk.checked;
      await load();
    };
  }

  wireEditModalClose();

  await load();
})();
