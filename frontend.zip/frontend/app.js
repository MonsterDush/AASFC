import { normalizePermList, permSetFromResponse, roleUpper, hasPerm, hasAnyPerm, hasPermPrefix } from "/permissions.js";

export const API_BASE = "https://api-dev.axelio.ru";
export const AUTH_PAGE = "/auth.html";

function isBrowser() {
  return typeof window !== "undefined" && typeof location !== "undefined";
}

export function isAuthPage() {
  return isBrowser() && /\/auth\.html$/i.test(location.pathname || "");
}

export function buildAuthUrl(next = "", reason = "") {
  const url = new URL(AUTH_PAGE, location.origin);
  const normalizedNext = String(next || "").trim();
  if (normalizedNext && !/\/auth\.html(\?|$)/i.test(normalizedNext)) {
    url.searchParams.set("next", normalizedNext);
  }
  const normalizedReason = String(reason || "").trim();
  if (normalizedReason) url.searchParams.set("reason", normalizedReason);
  return url.toString();
}

export function redirectToAuth(next = "", reason = "") {
  if (!isBrowser() || isAuthPage()) return;
  const current = next || `${location.pathname || "/"}${location.search || ""}${location.hash || ""}`;
  location.replace(buildAuthUrl(current, reason));
}

// ------------------------------
// i18n (RU/EN) MVP
// ------------------------------
const LS_LANG = "axelio.lang";
const DICT = {
  ru: {
    venue: "Заведение",
    manage_venues: "Управление заведениями",
    leave_venue: "Выйти из заведения",
    settings: "Настройки",
    adjustments: "Штрафы",
    shifts: "График",
    salary: "Зарплаты",
    report: "Отчёты",
    finance: "Финансы",
    revenue: "Выручка",
    summary: "Сводка",
    expenses: "Расходы",
    admin_venues: "Заведения",
    admin_invites: "Инвайты",
  },
  en: {
    venue: "Venue",
    manage_venues: "Manage venues",
    leave_venue: "Leave venue",
    settings: "Settings",
    adjustments: "Adjustments",
    shifts: "Schedule",
    salary: "Salary",
    report: "Reports",
    finance: "Finance",
    revenue: "Revenue",
    summary: "Summary",
    expenses: "Expenses",
    admin_venues: "Venues",
    admin_invites: "Invites",
  },
};

export function getLang() {
  try { return localStorage.getItem(LS_LANG) || "ru"; } catch { return "ru"; }
}

export function setLang(lang) {
  try { localStorage.setItem(LS_LANG, lang); } catch {}
}

export function t(key) {
  const lang = getLang();
  return (DICT[lang] && DICT[lang][key]) || (DICT.ru && DICT.ru[key]) || key;
}

export function wa() {
  return window.Telegram?.WebApp || null;
}

// ------------------------------
// Theme (system / light / dark / hookahplace)
// ------------------------------
const LS_THEME = "axelio.theme"; // 'system' | 'light' | 'dark' | 'hookahplace'
const LS_SYS_ROLE = "axelio.system_role"; // cached from /me (used for gated features)

export function cacheSystemRole(role) {
  const v = String(role || "").toUpperCase();
  try {
    if (v) localStorage.setItem(LS_SYS_ROLE, v);
    else localStorage.removeItem(LS_SYS_ROLE);
  } catch {}
}

export function getCachedSystemRole() {
  try { return String(localStorage.getItem(LS_SYS_ROLE) || "").toUpperCase(); } catch { return ""; }
}

export function isSuperAdminCached() {
  return getCachedSystemRole() === "SUPER_ADMIN";
}

export function getThemePref() {
  try {
    const v = (localStorage.getItem(LS_THEME) || "system").trim();
    const allowed = (v === "light" || v === "dark" || v === "system" || v === "hookahplace");
    if (!allowed) return "system";

    // Gate experimental themes by system role
    if (v === "hookahplace" && !isSuperAdminCached()) return "system";

    return v;
  } catch {
    return "system";
  }
}

export function setThemePref(pref) {
  let v = (pref === "light" || pref === "dark" || pref === "system" || pref === "hookahplace")
    ? pref
    : "system";

  if (v === "hookahplace" && !isSuperAdminCached()) v = "system";

  try { localStorage.setItem(LS_THEME, v); } catch {}
}

function ensureThemeMeta() {
  let m = document.querySelector('meta[name="theme-color"]');
  if (!m) {
    m = document.createElement("meta");
    m.setAttribute("name", "theme-color");
    document.head.appendChild(m);
  }
  return m;
}

function syncThemeColorMeta() {
  try {
    const m = ensureThemeMeta();
    const bg = getComputedStyle(document.documentElement).getPropertyValue("--bg").trim();
    // theme-color expects a solid color. Our themes keep --bg as a color (not a gradient).
    if (bg) m.setAttribute("content", bg);
  } catch {}
}

export function applyTheme() {
  const pref = getThemePref();
  const root = document.documentElement;

  // If user explicitly chose a theme, force it via data-theme.
  // If system: remove override and let CSS media query handle it.
  if (pref === "light" || pref === "dark" || pref === "hookahplace") {
    root.setAttribute("data-theme", pref);
  } else {
    root.removeAttribute("data-theme");
  }

  // keep mobile browser UI in sync (address bar color)
  requestAnimationFrame(syncThemeColorMeta);

  // react to system changes only when pref=system
  try {
    if (!root.__themeMqlBound) {
      const mql = window.matchMedia?.("(prefers-color-scheme: dark)");
      if (mql && typeof mql.addEventListener === "function") {
        mql.addEventListener("change", () => {
          if (getThemePref() === "system") requestAnimationFrame(syncThemeColorMeta);
        });
      }
      root.__themeMqlBound = true;
    }
  } catch {}
}

export function applyTelegramTheme() {
  // Our app theme (system/light/dark). Telegram themeParams are not used here,
  // because we want a stable brand theme + user override.
  applyTheme();

  const w = wa();
  const el = document.querySelector("[data-userpill]");
  if (!w) {
    if (el) el.textContent = "не в Telegram";
    return;
  }

  w.ready();

  const u = w.initDataUnsafe?.user;
  if (el) el.textContent = u ? `@${u.username || "без_username"}` : "неизвестно";
  // userpill is hidden globally for a cleaner, unified topbar.
}

export function toast(msg, type = "info") {
  const box = document.getElementById("toast");
  if (!box) return alert(msg);

  box.className = "toast show " + type;
  box.querySelector(".toast__text").textContent = msg;

  clearTimeout(box._t);
  box._t = setTimeout(() => (box.className = "toast"), 2400);
}

export function openModal(title, jsonOrText) {
  const m = document.getElementById("modal");
  if (!m) return;

  m.querySelector(".modal__title").textContent = title;

  const body = m.querySelector(".modal__body");
  if (!body) return;

  body.textContent = "";
  const pre = document.createElement("pre");
  pre.className = "json";
  pre.textContent =
    typeof jsonOrText === "string"
      ? jsonOrText
      : JSON.stringify(jsonOrText, null, 2);

  body.appendChild(pre);
  m.classList.add("open");
}

export function closeModal() {
  const m = document.getElementById("modal");
  if (m) m.classList.remove("open");
}

export function mountLogo() {
  document.querySelectorAll(".logo").forEach(el => {
    if (el.dataset.logoMounted) return;
    el.dataset.logoMounted = "1";

    // очистим, если там что-то было
    el.innerHTML = "";

    const img = document.createElement("img");
    img.src = "/logo.png"; // или /logo.svg
    img.alt = "Axelio";
    img.style.width = "100%";
    img.style.display = "block";

    el.appendChild(img);
  });
}

export function mountCommonUI(activeTab) {
  document.querySelectorAll("[data-tab]").forEach((a) => {
    if (a.getAttribute("data-tab") === activeTab) a.classList.add("active");
  });

  const modal = document.getElementById("modal");
  if (modal) {
    const closeBtn = modal.querySelector("[data-close]");
    const backdrop = modal.querySelector(".modal__backdrop");
    if (closeBtn) closeBtn.onclick = closeModal;
    if (backdrop) backdrop.onclick = closeModal;
  }
  mountLogo();
  document.querySelectorAll("[data-viewjson]").forEach((btn) => {
    btn.onclick = () =>
      openModal(btn.getAttribute("data-title") || "JSON", window.__lastJson || {});
  });
}

function isPlainObject(v) {
  return (
    v !== null &&
    typeof v === "object" &&
    !(v instanceof FormData) &&
    !(v instanceof Blob) &&
    !(v instanceof ArrayBuffer)
  );
}

function extractErrorMessage(data) {
  if (typeof data === "string") return data;

  // FastAPI часто отдаёт {detail: ...}
  if (data && typeof data === "object") {
    if (typeof data.detail === "string") return data.detail;
    if (Array.isArray(data.detail)) {
      // pydantic validation errors
      return data.detail.map((x) => x?.msg || JSON.stringify(x)).join("; ");
    }
  }
  try {
    return JSON.stringify(data);
  } catch {
    return String(data);
  }
}

/**
 * api("/path", { method:"POST", body: {a:1} })  // body-объект можно
 * api("/path", { method:"POST", body: JSON.stringify({a:1}) }) // тоже ок
 */
export async function api(path, opts = {}) {
  const url = API_BASE + path;

  // auto-jsonify object body (если передали объект)
  let body = opts.body;
  const isForm = (typeof FormData !== "undefined") && (body instanceof FormData);
  if (isPlainObject(body)) body = JSON.stringify(body);

  const handle401 = opts.handle401 !== false;

  // NOTE: Permission checks rely on fresh /me/* responses.
  // Some browsers may cache credentialed GET requests aggressively in certain flows.
  // Default to no-store, allow overriding via opts.cache when needed.
  const r = await fetch(url, {
    cache: "no-store",
    ...opts,
    body,
    credentials: "include",
    headers: {
      ...(isForm ? {} : { "Content-Type": "application/json" }),
      // extra cache-busting headers (safe no-op for most backends)
      "Cache-Control": "no-cache",
      Pragma: "no-cache",
      ...(opts.headers || {}),
    },
  });

  const text = await r.text();
  let data;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  if (!r.ok) {
    const err = new Error(`HTTP ${r.status} ${r.statusText}: ${extractErrorMessage(data)}`);
    err.status = r.status;
    err.data = data;
    err.url = r.url;

    if (r.status === 401 && handle401) {
      redirectToAuth("", "unauthorized");
    }

    throw err;
  }

  return data;
}

function parseDownloadFilename(contentDisposition, fallback = "download") {
  const header = String(contentDisposition || "");

  const starMatch = header.match(/filename\*=UTF-8''([^;]+)/i);
  if (starMatch?.[1]) {
    try {
      return decodeURIComponent(starMatch[1].trim()).replace(/[\r\n]/g, "") || fallback;
    } catch {}
  }

  const plainMatch = header.match(/filename=\"?([^";]+)\"?/i);
  if (plainMatch?.[1]) {
    return plainMatch[1].trim().replace(/[\r\n]/g, "") || fallback;
  }

  return fallback;
}

export async function downloadFile(path, { filenameFallback = "download", opts = {} } = {}) {
  const url = API_BASE + path;
  const r = await fetch(url, {
    cache: "no-store",
    credentials: "include",
    ...opts,
    headers: {
      "Cache-Control": "no-cache",
      Pragma: "no-cache",
      ...(opts.headers || {}),
    },
  });

  if (!r.ok) {
    let data = null;
    try {
      const text = await r.text();
      try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    } catch {}
    const err = new Error(`HTTP ${r.status} ${r.statusText}: ${extractErrorMessage(data)}`);
    err.status = r.status;
    err.data = data;
    err.url = r.url;
    throw err;
  }

  const blob = await r.blob();
  const filename = parseDownloadFilename(r.headers.get("Content-Disposition"), filenameFallback);
  const objectUrl = URL.createObjectURL(blob);
  try {
    const a = document.createElement("a");
    a.href = objectUrl;
    a.download = filename;
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
  } finally {
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  }

  return { filename };
}

export async function ensureLogin({ silent = true, redirectOnFail = false } = {}) {
  try {
    const me = await api("/me", { handle401: false });
    return { ok: true, data: me, source: "cookie" };
  } catch (e) {
    if (e?.status && e.status !== 401) {
      if (!silent) toast(e?.message || "Ошибка авторизации", "err");
      return { ok: false, status: e?.status, data: e?.data, message: e?.message };
    }
  }

  const w = wa();
  const initData = w?.initData || "";

  if (!initData) {
    if (!silent) toast("Нужна авторизация: Telegram или телефон.", "warn");
    if (redirectOnFail) redirectToAuth();
    return { ok: false, reason: "NO_INITDATA" };
  }

  try {
    const out = await api("/auth/telegram", {
      method: "POST",
      body: { initData },
      handle401: false,
    });

    if (!silent) toast("Вход выполнен", "ok");
    return { ok: true, data: out, source: "telegram" };
  } catch (e) {
    if (!silent) {
      const msg = e?.message || "Ошибка входа";
      toast(msg, "err");
    }
    if (redirectOnFail) redirectToAuth();
    return {
      ok: false,
      status: e?.status,
      data: e?.data,
      message: e?.message,
    };
  }
}


export async function loginWithTelegramWidget(authData) {
  return api("/auth/telegram/widget", {
    method: "POST",
    body: authData || {},
    handle401: false,
  });
}

export async function requestPhoneCode(phone) {
  return api("/auth/phone/request-code", {
    method: "POST",
    body: { phone },
    handle401: false,
  });
}

export async function verifyPhoneCode(phone, code) {
  return api("/auth/phone/verify-code", {
    method: "POST",
    body: { phone, code },
    handle401: false,
  });
}

export async function loginWithPassword(phone, password) {
  return api("/auth/password/login", {
    method: "POST",
    body: { phone, password },
    handle401: false,
  });
}

export async function setPasswordAfterPhoneVerify(phone, code, newPassword) {
  return api("/auth/password/set-after-phone-verify", {
    method: "POST",
    body: { phone, code, new_password: newPassword },
    handle401: false,
  });
}

export async function requestPasswordResetCode(phone) {
  return api("/auth/password/reset/request-code", {
    method: "POST",
    body: { phone },
    handle401: false,
  });
}

export async function confirmPasswordReset(phone, code, newPassword) {
  return api("/auth/password/reset/confirm", {
    method: "POST",
    body: { phone, code, new_password: newPassword },
    handle401: false,
  });
}

export async function getPasswordState() {
  return api("/auth/password/state");
}

export async function changePassword(currentPassword, newPassword) {
  return api("/auth/password/change", {
    method: "POST",
    body: { current_password: currentPassword, new_password: newPassword },
  });
}

export async function logout() {
  return api("/auth/logout", {
    method: "POST",
    handle401: false,
  });
}

export async function requestLinkPhoneCode(phone) {
  return api("/auth/link/phone/request-code", {
    method: "POST",
    body: { phone },
  });
}

export async function verifyLinkPhoneCode(phone, code, newPassword = "") {
  const body = { phone, code };
  const normalizedPassword = String(newPassword || "").trim();
  if (normalizedPassword) body.new_password = normalizedPassword;
  return api("/auth/link/phone/verify-code", {
    method: "POST",
    body,
  });
}

export async function linkTelegramAccount(initData = "") {
  const value = String(initData || wa()?.initData || "").trim();
  if (!value) throw new Error("Telegram Mini App недоступен для привязки");
  return api("/auth/link/telegram", {
    method: "POST",
    body: { initData: value },
  });
}

export function confirmModal({ title, text, confirmText = "Подтвердить", danger = false }) {
  return new Promise((resolve) => {
    const m = document.getElementById("modal");
    if (!m) return resolve(false);

    const titleEl = m.querySelector(".modal__title");
    const body = m.querySelector(".modal__body");
    if (!titleEl || !body) return resolve(false);

    titleEl.textContent = title;
    body.textContent = "";

    const p = document.createElement("div");
    p.className = "muted";
    p.style.marginTop = "10px";
    p.textContent = text;
    body.appendChild(p);

    const actions = document.createElement("div");
    actions.className = "row";
    actions.style.marginTop = "12px";

    const btnCancel = document.createElement("button");
    btnCancel.className = "btn";
    btnCancel.textContent = "Отмена";

    const btnOk = document.createElement("button");
    btnOk.className = "btn " + (danger ? "danger" : "primary");
    btnOk.textContent = confirmText;

    actions.appendChild(btnCancel);
    actions.appendChild(btnOk);
    body.appendChild(actions);

    const cleanup = (val) => {
      m.classList.remove("open");
      btnCancel.onclick = null;
      btnOk.onclick = null;
      resolve(val);
    };

    btnCancel.onclick = () => cleanup(false);
    btnOk.onclick = () => cleanup(true);

    m.classList.add("open");
  });
}

// ------------------------------
// Venue context + simple routing helpers (frontend MVP)
// ------------------------------
const LS_ACTIVE_VENUE = "axelio.activeVenueId";

export function getActiveVenueId() {
  try { return localStorage.getItem(LS_ACTIVE_VENUE) || ""; } catch { return ""; }
}

export function setActiveVenueId(id) {
  try {
    if (id === null || id === undefined || String(id).trim() === "") {
      localStorage.removeItem(LS_ACTIVE_VENUE);
      return;
    }
    localStorage.setItem(LS_ACTIVE_VENUE, String(id));
  } catch {}
}

export async function getMe() {
  return api("/me");
}

export async function getMyVenues() {
  return api("/me/venues");
}

export async function getMyVenuePermissions(venueId) {
  if (!venueId) return { venue_id: null, role: null, permissions: [] };
  return api(`/me/venues/${encodeURIComponent(venueId)}/permissions`);
}

// ------------------------------
// Venues: members + positions
// ------------------------------

export async function getVenueMembers(venueId) {
  if (!venueId) throw new Error("NO_VENUE");
  return api(`/venues/${encodeURIComponent(venueId)}/members`);
}

export async function getVenuePositions(venueId) {
  if (!venueId) throw new Error("NO_VENUE");
  return api(`/venues/${encodeURIComponent(venueId)}/positions`);
}

export async function createVenuePosition(venueId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  return api(`/venues/${encodeURIComponent(venueId)}/positions`, {
    method: "POST",
    body: payload,
  });
}

export async function updateVenuePosition(venueId, positionId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!positionId) throw new Error("NO_POSITION");
  return api(`/venues/${encodeURIComponent(venueId)}/positions/${encodeURIComponent(positionId)}`, {
    method: "PATCH",
    body: payload,
  });
}

export async function deleteVenuePosition(venueId, positionId) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!positionId) throw new Error("NO_POSITION");
  return api(`/venues/${encodeURIComponent(venueId)}/positions/${encodeURIComponent(positionId)}`, {
    method: "DELETE",
  });
}

// ------------------------------
// Venue settings
// ------------------------------

export async function getVenueSettings(venueId) {
  if (!venueId) throw new Error("NO_VENUE");
  return api(`/venues/${encodeURIComponent(venueId)}/settings`);
}

export async function updateVenueSettings(venueId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  return api(`/venues/${encodeURIComponent(venueId)}/settings`, {
    method: "PATCH",
    body: payload,
  });
}

// ------------------------------
// Invites (pending)
// ------------------------------

/**
 * Sets default position preset for a pending invite.
 * Backend endpoint: PATCH /venues/{venue_id}/invites/{invite_id}/default_position
 */
export async function patchInviteDefaultPosition(venueId, inviteId, defaultPosition) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!inviteId) throw new Error("NO_INVITE");
  return api(`/venues/${encodeURIComponent(venueId)}/invites/${encodeURIComponent(inviteId)}/default_position`, {
    method: "PATCH",
    body: { default_position: defaultPosition ?? null },
  });
}

// ------------------------------
// Catalogs: departments / payment methods / KPI metrics
// ------------------------------

export async function getDepartments(venueId, { includeArchived = false } = {}) {
  if (!venueId) throw new Error("NO_VENUE");
  const q = includeArchived ? "?include_archived=true" : "";
  return api(`/venues/${encodeURIComponent(venueId)}/departments${q}`);
}

export async function createDepartment(venueId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  return api(`/venues/${encodeURIComponent(venueId)}/departments`, { method: "POST", body: payload });
}

export async function updateDepartment(venueId, departmentId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!departmentId) throw new Error("NO_DEPARTMENT");
  return api(`/venues/${encodeURIComponent(venueId)}/departments/${encodeURIComponent(departmentId)}`, {
    method: "PATCH",
    body: payload,
  });
}

export async function getPaymentMethods(venueId, { includeArchived = false } = {}) {
  if (!venueId) throw new Error("NO_VENUE");
  const q = includeArchived ? "?include_archived=true" : "";
  return api(`/venues/${encodeURIComponent(venueId)}/payment-methods${q}`);
}

export async function createPaymentMethod(venueId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  return api(`/venues/${encodeURIComponent(venueId)}/payment-methods`, { method: "POST", body: payload });
}

export async function updatePaymentMethod(venueId, paymentMethodId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!paymentMethodId) throw new Error("NO_PAYMENT_METHOD");
  return api(`/venues/${encodeURIComponent(venueId)}/payment-methods/${encodeURIComponent(paymentMethodId)}`, {
    method: "PATCH",
    body: payload,
  });
}

export async function getKpiMetrics(venueId, { includeArchived = false } = {}) {
  if (!venueId) throw new Error("NO_VENUE");
  const q = includeArchived ? "?include_archived=true" : "";
  return api(`/venues/${encodeURIComponent(venueId)}/kpi-metrics${q}`);
}

export async function createKpiMetric(venueId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  return api(`/venues/${encodeURIComponent(venueId)}/kpi-metrics`, { method: "POST", body: payload });
}

export async function updateKpiMetric(venueId, kpiMetricId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!kpiMetricId) throw new Error("NO_KPI_METRIC");
  return api(`/venues/${encodeURIComponent(venueId)}/kpi-metrics/${encodeURIComponent(kpiMetricId)}`, {
    method: "PATCH",
    body: payload,
  });
}

/**
 * Boots a page: ensures login (cookie), loads /me,
 * optionally enforces an active venue (from LS or query).
 */


// ------------------------------
// Payroll: profiles / components / assignments / runs
// ------------------------------

export async function getPayProfiles(venueId, { includeInactive = false } = {}) {
  if (!venueId) throw new Error("NO_VENUE");
  const q = includeInactive ? "?include_inactive=true" : "";
  return api(`/venues/${encodeURIComponent(venueId)}/pay-profiles${q}`);
}

export async function getPayProfile(venueId, profileId) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!profileId) throw new Error("NO_PAY_PROFILE");
  return api(`/venues/${encodeURIComponent(venueId)}/pay-profiles/${encodeURIComponent(profileId)}`);
}

export async function createPayProfile(venueId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  return api(`/venues/${encodeURIComponent(venueId)}/pay-profiles`, { method: "POST", body: payload });
}

export async function updatePayProfile(venueId, profileId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!profileId) throw new Error("NO_PAY_PROFILE");
  return api(`/venues/${encodeURIComponent(venueId)}/pay-profiles/${encodeURIComponent(profileId)}`, {
    method: "PATCH",
    body: payload,
  });
}

export async function deletePayProfile(venueId, profileId) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!profileId) throw new Error("NO_PAY_PROFILE");
  return api(`/venues/${encodeURIComponent(venueId)}/pay-profiles/${encodeURIComponent(profileId)}`, {
    method: "DELETE",
  });
}

export async function createPayProfileAssignment(venueId, profileId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!profileId) throw new Error("NO_PAY_PROFILE");
  return api(`/venues/${encodeURIComponent(venueId)}/pay-profiles/${encodeURIComponent(profileId)}/assignments`, {
    method: "POST",
    body: payload,
  });
}

export async function updatePayProfileAssignment(venueId, assignmentId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!assignmentId) throw new Error("NO_ASSIGNMENT");
  return api(`/venues/${encodeURIComponent(venueId)}/pay-profile-assignments/${encodeURIComponent(assignmentId)}`, {
    method: "PATCH",
    body: payload,
  });
}

export async function deletePayProfileAssignment(venueId, assignmentId) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!assignmentId) throw new Error("NO_ASSIGNMENT");
  return api(`/venues/${encodeURIComponent(venueId)}/pay-profile-assignments/${encodeURIComponent(assignmentId)}`, {
    method: "DELETE",
  });
}

export async function createPayComponent(venueId, profileId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!profileId) throw new Error("NO_PAY_PROFILE");
  return api(`/venues/${encodeURIComponent(venueId)}/pay-profiles/${encodeURIComponent(profileId)}/components`, {
    method: "POST",
    body: payload,
  });
}

export async function updatePayComponent(venueId, componentId, payload) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!componentId) throw new Error("NO_COMPONENT");
  return api(`/venues/${encodeURIComponent(venueId)}/pay-components/${encodeURIComponent(componentId)}`, {
    method: "PATCH",
    body: payload,
  });
}

export async function deletePayComponent(venueId, componentId) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!componentId) throw new Error("NO_COMPONENT");
  return api(`/venues/${encodeURIComponent(venueId)}/pay-components/${encodeURIComponent(componentId)}`, {
    method: "DELETE",
  });
}

export async function calculatePayroll(venueId, month) {
  if (!venueId) throw new Error("NO_VENUE");
  return api(`/venues/${encodeURIComponent(venueId)}/payroll/calculate`, {
    method: "POST",
    body: { month },
  });
}

export async function getPayroll(venueId, month) {
  if (!venueId) throw new Error("NO_VENUE");
  if (!month) throw new Error("NO_MONTH");
  return api(`/venues/${encodeURIComponent(venueId)}/payroll?month=${encodeURIComponent(month)}`);
}

export async function bootPage({ requireVenue = false, silentLogin = true } = {}) {
  await ensureLogin({ silent: silentLogin });

  let me = null;
  try {
    me = await getMe();
  } catch (e) {
    return { ok: false, me: null, error: e };
  }

  let venues = null;
  if (requireVenue) {
    try {
      venues = await getMyVenues();
    } catch {
      venues = [];
    }

    let activeVenueId = getActiveVenueId();
    // If user has exactly one venue and none selected — auto-select
    if (!activeVenueId && Array.isArray(venues) && venues.length === 1) {
      activeVenueId = String(venues[0].id);
      setActiveVenueId(activeVenueId);
    }

    // Still no venue — go to venues picker
    if (!activeVenueId) {
      location.href = "/app-venues.html";
      return { ok: false, me, venues, redirected: true };
    }

    return { ok: true, me, venues, activeVenueId };
  }

  return { ok: true, me };
}

function escHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

/**
 * Renders a venue switcher <select> into container (or returns null if 0/1 venues).
 * onChange receives (newVenueId).
 */
export function renderVenueSwitcher({ container, venues, activeVenueId, onChange }) {
  if (!container) return null;
  if (!Array.isArray(venues) || venues.length <= 1) {
    container.innerHTML = "";
    return null;
  }

  container.innerHTML = "";

  const wrap = document.createElement("div");
  wrap.className = "venue-switch";

  const label = document.createElement("span");
  label.className = "venue-switch__label";
  label.textContent = "Venue:";

  const sel = document.createElement("select");
  sel.className = "venue-switch__select";

  venues.forEach((v) => {
    const opt = document.createElement("option");
    opt.value = String(v.id);
    opt.textContent = v.name ? v.name : `Venue #${v.id}`;
    sel.appendChild(opt);
  });

  sel.value = String(activeVenueId || venues[0].id || "");

  sel.onchange = () => {
    const id = sel.value;
    setActiveVenueId(id);
    if (typeof onChange === "function") onChange(id);
  };

  wrap.appendChild(label);
  wrap.appendChild(sel);
  container.appendChild(wrap);

  return sel;
}

/**
 * Convenience: loads /me/venues, renders switcher, and keeps URL in sync via onChange.
 * If current page uses ?venue_id=, we update that param and reload.
 */
export async function mountVenueSwitcher({ containerSelector = "#venueSwitcher", venues = null, onChange = null } = {}) {
  const el = document.querySelector(containerSelector);
  if (!el) return null;

  const v = venues || (await getMyVenues().catch(() => []));
  const active = getActiveVenueId() || (v[0] ? String(v[0].id) : "");

  return renderVenueSwitcher({
    container: el,
    venues: v,
    activeVenueId: active,
    onChange:
      onChange ||
      ((newId) => {
        const url = new URL(location.href);
        if (url.searchParams.has("venue_id")) url.searchParams.set("venue_id", newId);
        location.href = url.pathname + url.search;
      }),
  });
}

export async function getVenueById(venueId) {
  if (!venueId) return null;

  // Берём из "моих заведений" (это доступно OWNER/STAFF)
  const list = await api("/me/venues");
  const v = (list || []).find(x => String(x.id) === String(venueId));
  return v || null;
}
// ------------------------------
// Permissions + dynamic navigation (A2/A3)
// ------------------------------


export function can(permCode, venuePerms) {
  if (!permCode) return false;
  const list = normalizePermList(venuePerms?.permissions || venuePerms);
  return list.includes(String(permCode));
}


function renderNavLinks({ container, links, activeTab }) {
  if (!container) return;
  container.innerHTML = "";

  links.forEach((l) => {
    const a = document.createElement("a");
    a.href = l.href;
    a.textContent = l.title;
    if (l.className) a.className = l.className;
    a.setAttribute("data-tab", l.tab);
    if (l.tab === activeTab) a.classList.add("active");
    container.appendChild(a);
  });
}

/**
 * Mounts a bottom nav with only allowed items.
 *
 * Rules (MVP):
 * - SUPER_ADMIN: admin pages only
 * - Others: Venues + (if active venue) Venue/Invites
 *
 * Later we'll extend links as we add pages (Shifts/Salary/Adjustments/Reports).
 */
export async function mountNav({ activeTab = "dashboard", containerSelector = "#nav" } = {}) {
  const container = document.querySelector(containerSelector);
  if (!container) return { ok: false, reason: "NO_CONTAINER" };

  // Deep links: if venue_id is in URL, treat it as active venue (prevents missing owner navbar)
  try {
    const qv = new URLSearchParams(location.search).get("venue_id");
    if (qv) setActiveVenueId(qv);
  } catch {}

  await ensureLogin({ silent: true });

  let me = null;
  try { me = await getMe(); } catch {
    container.innerHTML = "";
    return { ok: false, reason: "NO_ME" };
  }

  // cache system role for gated features (themes, admin-only UI)
  cacheSystemRole(me?.system_role);
  // re-apply theme now that role is known (enables SUPER_ADMIN-only themes)
  applyTheme();

  // SUPER_ADMIN bottom nav
  if (me?.system_role === "SUPER_ADMIN") {
    renderNavLinks({
      container,
      links: [
        { title: t("admin_venues"), href: "/admin-venues.html", tab: "admin-venues" },
        { title: t("admin_invites"), href: "/admin-invites.html", tab: "admin-invites" },
        { title: "⚙️", href: "/settings.html", tab: "settings", className: "icon" },
      ],
      activeTab,
    });
    return { ok: true, me };
  }

  // Regular users (OWNER/STAFF)
  let venues = [];
  try { venues = await getMyVenues(); } catch { venues = []; }

  let activeVenueId = getActiveVenueId();

  // If user has venues but no active venue chosen yet, pick the first one automatically.
  // This prevents "2-tab navbar" on pages that require a venue context.
  try {
    const page = (location.pathname.split("/").pop() || "").toLowerCase();
    const isVenuePicker = page === "app-venues.html";
    if (!activeVenueId && !isVenuePicker && venues.length >= 1) {
      activeVenueId = String(venues[0].id);
      setActiveVenueId(activeVenueId);
    } else if (!activeVenueId && venues.length === 1) {
      activeVenueId = String(venues[0].id);
      setActiveVenueId(activeVenueId);
    }
  } catch {
    if (!activeVenueId && venues.length === 1) {
      activeVenueId = String(venues[0].id);
      setActiveVenueId(activeVenueId);
    }
  }

// Determine permissions for active venue (best-effort)
let isOwner = false;
let canViewReports = false;

const activeVenue = activeVenueId ? venues.find(v => String(v.id) === String(activeVenueId)) : null;
const roleFromList = String(activeVenue?.role || activeVenue?.venue_role || activeVenue?.my_role || "").toUpperCase();

if (activeVenueId) {
  try {
    const permsResp = await getMyVenuePermissions(activeVenueId);
    const role = roleUpper(permsResp) || roleFromList;
    isOwner = role === "OWNER" || role === "VENUE_OWNER";

    const pset = permSetFromResponse(permsResp);

    // Report access means: user can open report pages / close shift / see report sections.
    canViewReports =
      isOwner ||
      hasPermPrefix(pset, "SHIFT_REPORT_") ||
      hasPermPrefix(pset, "REPORTS_") ||
      hasAnyPerm(pset, [
        "SHIFT_REPORT_VIEW",
        "SHIFT_REPORT_CLOSE",
        "SHIFT_REPORT_EDIT",
        "SHIFT_REPORT_REOPEN",
        "REPORTS_VIEW_DAILY",
        "REPORTS_VIEW_MONTHLY",
        "REPORTS_VIEW_PNL",
      ]);
  } catch {
    isOwner = roleFromList === "OWNER" || roleFromList === "VENUE_OWNER";
    canViewReports = isOwner;
  }
}

const qp = activeVenueId ? `?venue_id=${encodeURIComponent(activeVenueId)}` : "";

  const links = [];

  if (activeVenueId) {
    if (isOwner) {      // Owner bottom nav: Venue / Summary / Expenses
      links.push({ title: t("venue"), href: `/app-venue.html${qp}`, tab: "venue" });      links.push({ title: t("summary"), href: `/owner-summary.html${qp}`, tab: "summary" });
      links.push({ title: t("expenses"), href: `/owner-expenses.html${qp}`, tab: "expenses" });
      links.push({ title: "⚙️", href: "/settings.html", tab: "settings", className: "icon" });
    } else {
      // Staff bottom nav:
// - If NO report access: Schedule + Salaries + Adjustments + Settings
// - If HAS report access: Schedule + Finance + Reports + Settings
links.push({ title: t("shifts"), href: `/staff-shifts.html${qp}`, tab: "shifts" });

if (canViewReports) {
  links.push({ title: t("finance"), href: `/staff-finance.html${qp}`, tab: "finance" });
  links.push({ title: t("report"), href: `/staff-report.html${qp}`, tab: "report" });
} else {
  links.push({ title: t("salary"), href: `/staff-salary.html${qp}`, tab: "salary" });
  links.push({ title: t("adjustments"), href: `/staff-adjustments.html${qp}`, tab: "adjustments" });
}

links.push({ title: "⚙️", href: "/settings.html", tab: "settings", className: "icon" });
    }
  } else {
    // No active venue chosen yet
    links.push({ title: t("manage_venues"), href: "/app-venues.html", tab: "app-venues" });
    links.push({ title: "⚙️", href: "/settings.html", tab: "settings", className: "icon" });
  }

  renderNavLinks({ container, links, activeTab });
  return { ok: true, me, venues, activeVenueId };
}

// ------------------------------
// Venue dropdown menu (topbar)
// ------------------------------
export async function leaveVenue(venueId) {
  if (!venueId) throw new Error("NO_VENUE");
  return api(`/venues/${encodeURIComponent(venueId)}/leave`, { method: "POST" });
}

export async function mountVenueMenu({ containerSelector = "#venueMenu", onVenueChanged = null } = {}) {
  const el = document.querySelector(containerSelector);
  if (!el) return null;

  let venues = [];
  try { venues = await getMyVenues(); } catch { venues = []; }

  // Always show, even if 0/1 venues
  const active = getActiveVenueId() || (venues[0] ? String(venues[0].id) : "");
  if (active) setActiveVenueId(active);

  el.innerHTML = "";

  const wrap = document.createElement("div");
  wrap.className = "venue-switch";

  const label = document.createElement("span");
  label.className = "venue-switch__label";
  label.textContent = t("venue") + ":";

  const sel = document.createElement("select");
  sel.className = "venue-switch__select";

  if (!venues.length) {
    const opt = document.createElement("option");
    opt.value = "";
    opt.textContent = "—";
    sel.appendChild(opt);
  } else {
    for (const v of venues) {
      const opt = document.createElement("option");
      opt.value = String(v.id);
      opt.textContent = v.name ? v.name : `#${v.id}`;
      sel.appendChild(opt);
    }
  }

  // action items
  const optManage = document.createElement("option");
  optManage.value = "__manage__";
  optManage.textContent = "────────";
  optManage.disabled = true;
  sel.appendChild(optManage);

  const optManage2 = document.createElement("option");
  optManage2.value = "__manage2__";
  optManage2.textContent = t("manage_venues");
  sel.appendChild(optManage2);

  sel.value = active || (venues[0] ? String(venues[0].id) : "");

  sel.onchange = async () => {
    const val = sel.value;
    if (val === "__manage2__") {
      location.href = "/app-venues.html";
      return;
    }

    // normal venue switch
    setActiveVenueId(val);
    if (typeof onVenueChanged === "function") onVenueChanged(val);
    else {
      const url = new URL(location.href);
      if (url.searchParams.has("venue_id")) url.searchParams.set("venue_id", val);
      location.href = url.pathname + url.search;
    }
  };

  wrap.appendChild(label);
  wrap.appendChild(sel);
  el.appendChild(wrap);
  return sel;
}
